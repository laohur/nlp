'''
训练后台程序
'''
import time
import math
from tqdm import tqdm
import torch
from eval import eval_performance
import transformer.Constants as Constants


def train(model, training_data, validation_data, optimizer, device, args):
    ''' 开始训练'''
    log_train_file = args.log + '/train.log'
    log_valid_file = args.log + '/valid.log'

    print('[Info] 训练记录写入 {} and {}'.format(log_train_file, log_valid_file))

    with open(log_train_file, 'a') as log_tf, open(log_valid_file, 'a') as log_vf:
        log_tf.write('epoch, loss, ppl, accuracy\n')
        log_vf.write('epoch, loss, ppl, accuracy\n')

    valid_accus = []
    for epoch_i in range(args.epoch):
        print('[ Epoch', epoch_i, ']')

        start = time.time()
        train_loss, train_accu = train_epoch(model, training_data, optimizer, device, smoothing=args.label_smoothing)
        print('  - (训练集)   ppl: {ppl: 8.5f}, accuracy: {accu:3.3f} %, time: {time:3.3f}秒'.format(
            ppl=math.exp(min(train_loss, 100)), accu=100 * train_accu, time=(time.time() - start)))

        start = time.time()
        valid_loss, valid_accu = eval_epoch(model, validation_data, device)
        print('  - (验证集) ppl: {ppl: 8.5f}, accuracy: {accu:3.3f} %, time: {time:3.3f}秒'.format(
            ppl=math.exp(min(valid_loss, 100)), accu=100 * valid_accu,
            time=(time.time() - start)))

        valid_accus += [valid_accu]

        model_state_dict = model.state_dict()
        checkpoint = {
            'model': model_state_dict,
            'settings': args,
            'epoch': epoch_i}

        if args.save_model:
            model_name = None
            if args.save_mode == 'all':
                model_name = args.log + '/' + args.save_model + '_accu_{accu:3.3f}.ckpt'.format(accu=100 * valid_accu)
            elif args.save_mode == 'best':
                if valid_accu >= max(valid_accus):
                    model_name = args.log + '/' + args.save_model + '.ckpt'
            if model_name:
                torch.save(checkpoint, model_name)
                print('    - [Info] 模型保存于' + model_name)

        if log_train_file and log_valid_file:
            with open(log_train_file, 'a') as log_tf, open(log_valid_file, 'a') as log_vf:
                log_tf.write('{epoch}, {loss: 8.5f}, {ppl: 8.5f}, {accu:3.3f}\n'.format(
                    epoch=epoch_i, loss=train_loss,
                    ppl=math.exp(min(train_loss, 100)), accu=100 * train_accu))
                log_vf.write('{epoch}, {loss: 8.5f}, {ppl: 8.5f}, {accu:3.3f}\n'.format(
                    epoch=epoch_i, loss=valid_loss,
                    ppl=math.exp(min(valid_loss, 100)), accu=100 * valid_accu))


def train_epoch(model, training_data, optimizer, device, smoothing):
    ''' Epoch 后台程序'''
    # training_data DataLoader
    model.train()

    total_loss = 0
    n_word_total = 0
    n_word_correct = 0

    for batch in tqdm(training_data, mininterval=20, desc='  - (训练)   ', leave=False):
        # prepare data
        src_seq, src_pos, tgt_seq, tgt_pos = map(lambda x: x.to(device), batch)

        # if teacher force

        gold = tgt_seq[:, 1:]

        # forward
        optimizer.zero_grad()
        pred = model(src_seq, src_pos, tgt_seq, tgt_pos)
        _ = torch.nn.utils.clip_grad_norm_(model.parameters(), 50)
        # backward
        loss, n_correct = eval_performance(pred, gold, smoothing=smoothing)
        loss.backward()

        # update parameters
        optimizer.step_and_update_lr()

        # note keeping
        total_loss += loss.item()

        non_pad_mask = gold.ne(Constants.PAD)
        n_word = non_pad_mask.sum().item()
        n_word_total += n_word
        n_word_correct += n_correct

    loss_per_word = total_loss / n_word_total
    accuracy = n_word_correct / n_word_total
    return loss_per_word, accuracy


def eval_epoch(model, validation_data, device):
    ''' Epoch 验证 '''

    model.eval()

    total_loss = 0
    n_word_total = 0
    n_word_correct = 0

    with torch.no_grad():
        for batch in tqdm(validation_data, mininterval=2, desc='  - (验证) ', leave=False):
            # prepare data
            src_seq, src_pos, tgt_seq, tgt_pos = map(lambda x: x.to(device), batch)
            gold = tgt_seq[:, 1:]

            # forward
            pred = model(src_seq, src_pos, tgt_seq, tgt_pos)
            loss, n_correct = eval_performance(pred, gold, smoothing=False)

            # note keeping
            total_loss += loss.item()

            non_pad_mask = gold.ne(Constants.PAD)
            n_word = non_pad_mask.sum().item()
            n_word_total += n_word
            n_word_correct += n_correct

    loss_per_word = total_loss / n_word_total
    accuracy = n_word_correct / n_word_total
    return loss_per_word, accuracy
