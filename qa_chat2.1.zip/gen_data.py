import argparse
import torch
import os
from time import time
import random
from Util import *


def char_type(c):  # 判断字符类型
    # https://gist.github.com/shingchi/64c04e0dd2cbbfbc1350
    if ord(c) <= 0x007f:  # ascii
        if ord(c) >= 0x0030 and ord(c) <= 0x0039:
            return "number"
        if ord(c) >= 0x0041 and ord(c) <= 0x005a:
            return "latin"
        if ord(c) >= 0x0061 and ord(c) <= 0x007a:
            return "latin"
        return "ascii_symble"
    if ord(c) >= 0x4E00 and ord(c) <= 0x9fff:
        return "han"  # 标准CJK文字
    if ord(c) >= 0xFF00 and ord(c) <= 0xFFEF:
        return "han_symble"  # 全角ASCII、全角中英文标点、半宽片假名、半宽平假名、半宽韩文字母：FF00-FFEF
    if ord(c) >= 0x3000 and ord(c) <= 0x303F:
        return "han_symble"  # CJK标点符号：3000-303F
    return "other"


def split_lans(line):
    last_latin = None
    grams = []
    for gram in line:  # 还是字符串形式
        if char_type(gram) == "latin":
            if last_latin == None or last_latin == False:
                grams.append(gram)
            else:
                grams[-1] += gram
            last_latin = True
        else:
            grams.append(gram)
            last_latin = False
    return grams


def merge_gram(line):
    last_type = None
    tokens = []
    for gram in line:
        if char_type(gram) == "latin":
            if last_type == "latin":
                tokens[-1] += gram
            else:
                tokens.append(gram)
        elif char_type(gram) == "number":
            if last_type == "number":
                tokens[-1] += gram
            else:
                tokens.append(gram)
        else:
            if gram not in [None, '', ' ']:
                tokens.append(gram)
        last_type = char_type(gram)
    return tokens


def tokenize(line):
    # return list(line)
    # return line.split(" ")
    # words = line.split()
    # line = ''.join(line.split(" "))
    # words = split_lans(line)
    words = merge_gram(line)
    # line = ' '.join(words)
    # words = line.split(" ")
    re = []
    for word in words:
        if len(word) > 7:
            continue
        if word:
            re.append(word)
    return re


def tb_pair(row):
    words = row.split("\t")
    # 数据多，出错丢弃.如果数据出错，前面几段都归为问题，最后一个归为回答.
    if len(words) < 3 or int(words[0]) != 1:
        return None, None
    question = words[1].strip()
    answer = words[2].strip()

    question = " ".join(tokenize(question))
    answer = " ".join(tokenize(answer))

    if len(question) < 2 or len(answer) < 2:
        print("tb_pair字太少", row)
        return None, None
    return question, answer


def get_pair(row):
    sents = row.split("\t")
    if len(sents) < 2:
        return None, None
    # question = pure(sents[0].strip())
    # answer = pure(sents[1].strip())
    question = sents[0].strip()
    answer = sents[1].strip()

    question = " ".join(tokenize(question))
    answer = " ".join(tokenize(answer))

    # if len(question) < 1 or len(answer) < 1:
    #     print("get_pair字太少", row)
    #     return None, None
    return question, answer


def read(path, begin=0, end=-1):
    t0 = time()
    print("read正在读取", os.path.abspath(path))
    doc = open(path, "r", encoding="utf-8").read().splitlines()
    random.shuffle(doc)
    if end < 0:
        end = len(doc)
    print(time() - t0, "秒读出", len(doc), "条")
    t0 = time()
    qlenth, alenth = 0, 0  # 问题长度
    questions, answers = [], []
    for i in range(len(doc)):
        if i < begin:
            continue
        if i > end:
            break
        row = doc[i]
        # question, answer = tb_pair(row)
        question, answer = get_pair(row)
        if question == None or answer == None:
            continue

        qlenth += len(question)
        alenth += len(answer)
        questions.append(question)
        answers.append(answer)

        if i % 100000 == 0:
            print("进展", i * 100.0 / (end - begin), "第", i, "行", question, "--->", answer)

    assert len(answers) == len(questions)
    print(str(path) + "总计", len(doc), "行，有效问答有" + str(len(answers)))
    print("平均问题长", qlenth / len(questions), "平均回答长", alenth / len(answers))
    print(time() - t0, "秒处理", len(answers), "条")
    return questions, answers


def read_big(path, begin=0, end=sys.maxsize):
    if end < 0:
        end = sys.maxsize
    t0 = time()
    print("read正在读取", os.path.abspath(path))
    f = open(path, "r", encoding="utf-8")
    line = f.readline()
    print("第一条", line)
    i = 0
    t0 = time()
    qlenth, alenth = 0, 0  # 问题长度
    questions, answers = [], []
    while (line):
        i += 1
        if i < begin:
            continue
        if i > end:
            break
        row = line
        # question, answer = tb_pair(row)
        question, answer = get_pair(row)
        if question == None or answer == None:
            continue

        qlenth += len(question)
        alenth += len(answer)
        questions.append(question)
        answers.append(answer)
        line = f.readline()

        if i % 100000 == 0:
            print("进展", i * 100.0 / (end - begin), "第", i, "行", question, "--->", answer)

    assert len(answers) == len(questions)
    print(str(path) + "总计", i, "行，有效问答有" + str(len(answers)))
    print("平均问题长", qlenth / len(questions), "平均回答长", alenth / len(answers))
    print(time() - t0, "秒处理", len(answers), "条")
    return questions, answers


def splits_write(x, suffix, dir):  # 此处不能独自洗牌，应该对问答对洗牌
    print("splits_write正在划分训练集", os.path.abspath(dir))
    test_len, valid_len = 200, 1000
    # right = len(x) - test_len
    # left = right - valid_len

    with open(dir + "/test" + suffix, "w", encoding="utf-8") as f:
        f.write("\n".join(x[:test_len]))
    print("测试集已写入")
    with open(dir + "/valid" + suffix, "w", encoding="utf-8") as f:
        f.write("\n".join(x[test_len:valid_len]))
    print("验证集已写入")
    with open(dir + "/train" + suffix, "w", encoding="utf-8") as f:
        f.write("\n".join(x[valid_len:]))
    print("训练集、验证集、测试集已写入", os.path.abspath(dir), "目录下")


def main():
    # dir = "../data/tb"
    # source = "/train.txt"

    # dir = "../data/qa_data"
    # source = "qa_data.txt"

    # dir = "../data/chitchat_data"
    # source = "chitchat_data.txt"

    dir = "../data/all"
    # source = "balance.txt"
    source = "all.txt"

    questions, answers = read_big(dir + "/" + source, begin=0, end=-1)
    splits_write(questions, dir="data", suffix="_src.txt")
    splits_write(answers, dir="data", suffix="_tgt.txt")


if __name__ == '__main__':
    main()
