"处理文本"
import argparse
import torch
import transformer.Constants as Constants
import json
import math
from time import time
import os
from Util import *


def main():
    # dir = "../data/tb"
    # dir = "../data/qa_data"
    dir = "data"
    parser = argparse.ArgumentParser()
    parser.add_argument('-train_src', default=dir + "/train_src.txt")
    parser.add_argument('-train_tgt', default=dir + "/train_tgt.txt")
    parser.add_argument('-valid_src', default=dir + "/valid_src.txt")
    parser.add_argument('-valid_tgt', default=dir + "/valid_tgt.txt")
    parser.add_argument('-save_dir', default="data")
    parser.add_argument('-max_len', '--max_word_seq_len', type=int, default=20)
    parser.add_argument('-min_word_count', type=int, default=2)
    parser.add_argument('-keep_case', action='store_true', default=False)
    parser.add_argument('-share_vocab', action='store_true', default=True)
    parser.add_argument('-vocab', default=None)

    args = parser.parse_args()
    args.max_token_seq_len = args.max_word_seq_len + 2  # include the <s> and </s>

    # Training set

    # train_src_word_insts = load_file(args.train_src, args.max_word_seq_len, args.keep_case, begin=0, end=100000)
    # train_tgt_word_insts = load_file(args.train_tgt, args.max_word_seq_len, args.keep_case, begin=0, end=100000)
    train_src_word_insts = read_file(args.train_src, args.keep_case, begin=0, end=-1)
    train_tgt_word_insts = read_file(args.train_tgt, args.keep_case, begin=0, end=-1)

    if len(train_src_word_insts) != len(train_tgt_word_insts):
        print('[Warning] 训练集源标句子数量不等,将被截断' + args.train_src, len(train_src_word_insts), args.train_tgt, len(train_tgt_word_insts))
        min_inst_count = min(len(train_src_word_insts), len(train_tgt_word_insts))
        train_src_word_insts = train_src_word_insts[:min_inst_count]
        train_tgt_word_insts = train_tgt_word_insts[:min_inst_count]

    # Remove empty instances
    train_src_word_insts, train_tgt_word_insts = list(zip(*[
        (s, t) for s, t in zip(train_src_word_insts, train_tgt_word_insts) if s and t]))

    # Validation set
    # valid_src_word_insts = load_file(args.valid_src, args.max_word_seq_len, args.keep_case, begin=0, end=-1)
    # valid_tgt_word_insts = load_file(args.valid_tgt, args.max_word_seq_len, args.keep_case, begin=0, end=-1)
    valid_src_word_insts = read_file(args.valid_src, args.keep_case, begin=0, end=-1)
    valid_tgt_word_insts = read_file(args.valid_tgt, args.keep_case, begin=0, end=-1)

    if len(valid_src_word_insts) != len(valid_tgt_word_insts):
        print('[Warning] 源标句子数量不等,将被截断')
        print(args.valid_src, len(valid_src_word_insts), args.valid_tgt, len(valid_tgt_word_insts))
        min_inst_count = min(len(valid_src_word_insts), len(valid_tgt_word_insts))
        valid_src_word_insts = valid_src_word_insts[:min_inst_count]
        valid_tgt_word_insts = valid_tgt_word_insts[:min_inst_count]

    # Remove empty instances
    valid_src_word_insts, valid_tgt_word_insts = list(zip(*[
        (s, t) for s, t in zip(valid_src_word_insts, valid_tgt_word_insts) if s and t]))

    # Build vocabulary
    if args.vocab:
        predefined_data = torch.load(args.vocab)
        assert 'dict' in predefined_data

        print('[Info] 加载词典')
        src_word2idx = predefined_data['dict']['src']
        tgt_word2idx = predefined_data['dict']['tgt']
    else:
        if args.share_vocab:
            print('[Info] 构建共同词典')
            word2idx, frequency = build_vocab_idx(train_src_word_insts + train_tgt_word_insts, args.min_word_count)
            src_word2idx = tgt_word2idx = word2idx
            # print("word2idx", word2idx)
        else:
            print('[Info] 从源文本构建词典')
            src_word2idx, frequency = build_vocab_idx(train_src_word_insts, args.min_word_count)
            print('[Info] 从文本构建词典')
            tgt_word2idx, frequency = build_vocab_idx(train_tgt_word_insts, args.min_word_count)

    # word to index
    print('[Info] 源文本字典序列化')
    # train_src_insts = convert_w2id_seq(train_src_word_insts, src_word2idx)
    # valid_src_insts = convert_w2id_seq(valid_src_word_insts, src_word2idx)
    # train_src_insts,valid_src_insts=digitalize(src=train_src_word_insts,tgt=train_tgt_word_insts,max_sent_len=args.max_word_seq_len,word2idx=src_word2idx)
    # print("训练集源  train_src_insts", len(train_src_insts), "验证集源 valid_src_insts", len(valid_src_insts))

    print('[Info] 标文本字典序列化')
    # train_tgt_insts = convert_w2id_seq(train_tgt_word_insts, tgt_word2idx)
    # valid_tgt_insts = convert_w2id_seq(valid_tgt_word_insts, tgt_word2idx)
    # print("训练集标  train_tgt_insts", len(train_tgt_insts), "验证集标 valid_tgt_insts", len(valid_tgt_insts))

    # for line in valid_tgt_insts:
    #     print(len(line),line)
    # 10[2, 1989, 159, 1858, 2587, 1, 2457, 2868, 2101, 3]
    # 17[2, 1989, 2667, 2402, 1169, 667, 1371, 1304, 1993, 285, 2879, 1131, 1, 1, 2404, 2101, 3]

    vocab = {
        'settings': vars(args),
        'dict': {
            'src': src_word2idx,
            'tgt': tgt_word2idx,
            'frequency': frequency
        }}

    # data = {
    #     'settings': args,
    #     'frequency': frequency,
    #     'dict': {
    #         'src': src_word2idx,
    #         'tgt': tgt_word2idx},
    #     'train': {
    #         'src': train_src_insts,
    #         'tgt': train_tgt_insts},
    #     'valid': {
    #         'src': valid_src_insts,
    #         'tgt': valid_tgt_insts}}

    path = args.save_dir + "/reader.json"
    with open(path, "w", encoding="utf-8") as f:  # 特殊字符有问题，仅供人类阅读
        json.dump(vocab, f, ensure_ascii=False)

    # vocab = {
    #     'settings': args,
    #     'frequency': frequency,
    #     'dict': {
    #         'src': src_word2idx,
    #         'tgt': tgt_word2idx}}
    path = args.save_dir + "/reader.data"
    print('[Info] 保存词汇到', os.path.abspath(path))
    torch.save(vocab, path)

    # data = {
    #     'train': {
    #         'src': train_src_insts,
    #         'tgt': train_tgt_insts},
    #     'valid': {
    #         'src': valid_src_insts,
    #         'tgt': valid_tgt_insts}}
    # path = args.save_dir + "/train.data"
    # print('[Info] 保存训练数据到', os.path.abspath(path))
    # torch.save(data, path)
    # print('[Info] Finished.')


if __name__ == '__main__':
    main()

'''
进展 98.97607191601385 第 24000000 行 
[Info] ""文件data/train_tgt.txt中获取24248285句子 耗时 14.559921264648438
load_file正在读取 /home/cs/qa_chat/data/valid_src.txt 0 -> 9223372036854775807
进展 0.0 第 0 行 腾 讯 录 用 我 了
[Info] ""文件data/valid_src.txt中获取800句子 耗时 0.0006761550903320312
load_file正在读取 /home/cs/qa_chat/data/valid_tgt.txt 0 -> 9223372036854775807
进展 0.0 第 0 行 你 真 棒 ， 接 下 来 就 努 力 做 好 每 天 的 工 作 吧 。
[Info] ""文件data/valid_tgt.txt中获取800句子 耗时 0.0006234645843505859
[Info] 构建共同词典
[Info] 原始词库 = 22236
词频 {' ': 677974005, '的': 19916211, '，': 17158831, '是': 11522220, '么...
[Info] 频繁字典大小 = 19159, 最低频数 = 2
[Info] 忽略罕词数 = 3081 爆表词汇数 -77764
[Info] 源文本字典序列化
[Info] 标文本字典序列化
[Info] 保存词汇到 /home/cs/qa_chat/data/reader.data


'''