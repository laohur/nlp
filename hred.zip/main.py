# Implementation of HRED model in PyTorch
# Paper : https://arxiv.org/abs/1507.04808
# python hred_pytorch.py <training_data> <dictionary>

import torch
import torch.nn as nn
from torch.autograd import Variable
from torch import optim
# from torch.optim.lr_scheduler import StepLR
import torch.nn.functional as F
import json
import pickle as pkl
import random
import sys
import time
import math
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
import re
import os.path
from models import *
from Util import *
from HRED_QA import *


# torch.set_default_tensor_type('torch.half')

def load_data(path):
    doc = open(path, "r", encoding="utf-8").read().strip().splitlines()
    for i in range(len(doc)):
        doc[i] = doc[i].split("\t")
    return doc


if __name__ == '__main__':
    # prepare data
    dir = "../data/chitchat_data"
    path = "/train.txt"
    t0 = time()
    counter_path = dir + "/chit_chat_counter.tsv"
    counter = load_counter(counter_path)
    dict = counter2dict(counter)
    print(dict)
    print("加载词典", time() - t0)
    groups = load_data(dir + path)
    t0 = time()

    word2id = dict
    id2word = get_index2word(dict)
    EOS_token = Constants.EOS
    SOS_token = Constants.BOS
    hidden_size = 512
    # calculate max sentence length
    max_len = 0
    for gr in groups:
        ws = [p.split(' ') for p in gr]
        ws = max([len(p) for p in ws])
        if ws > max_len:
            max_len = ws
    print("句长", max_len, "字典长", len(word2id.keys()))
    encoder1 = EncoderRNN(len(word2id.keys()), hidden_size).to(device)
    # encoder1.load_state_dict(torch.load('encoder_5.model')).to(device)
    attn_decoder1 = AttnDecoderRNN(hidden_size, len(word2id.keys()), 1, dropout_p=0.1).to(device)
    # attn_decoder1.load_state_dict(torch.load('decoder_5.model')).to(device)
    context1 = ContextRNN(hidden_size, len(word2id.keys())).to(device)
    # context1.load_state_dict(torch.load('context_5.model')).to(device)
    # print( "loaded models")

    # trainIters(encoder1, attn_decoder1, context1, print_every=100, evaluate_every=600)
    # hredQA = HRED_QA(groups=groups,
    #         dictionary=dict,
    #         encoder_file='encoder_5.model',
    #         decoder_file='decoder_5.model',
    #         context_file='context_5.model')
    hredQA = HRED_QA(groups=groups,
                     dictionary=dict,
                     id2word=id2word,
                     word2id=word2id,
                     )
    hredQA.trainIters()
