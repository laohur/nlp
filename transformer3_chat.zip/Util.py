import os
import re
from time import time
import random
# import Constants
import sys
import torch
import json
import numpy as np
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

PAD = 0
UNK = 1
BOS = 2
EOS = 3

PAD_WORD = '<blank>'
UNK_WORD = '<unk>'
BOS_WORD = '<s>'
EOS_WORD = '</s>'

Default_Dict={
    PAD_WORD: PAD,
    UNK_WORD: UNK,
    BOS_WORD: BOS,
    EOS_WORD: EOS
}


def unicode_type(unicode):  # 判断字符类型
    # https://gist.github.com/shingchi/64c04e0dd2cbbfbc1350
    if ord(unicode) <= 0x007f:  # ascii
        if ord(unicode) >= 0x0041 and ord(unicode) <= 0x005a:
            return "latin"
        if ord(unicode) >= 0x0061 and ord(unicode) <= 0x007a:
            return "latin"
        return "ascii_symble"
    if ord(unicode) >= 0x4E00 and ord(unicode) <= 0x9fff:
        return "han"  # 标准CJK文字
    if ord(unicode) >= 0xFF00 and ord(unicode) <= 0xFFEF:
        return "han_symble"  # 全角ASCII、全角中英文标点、半宽片假名、半宽平假名、半宽韩文字母：FF00-FFEF
    if ord(unicode) >= 0x3000 and ord(unicode) <= 0x303F:
        return "han_symble"  # CJK标点符号：3000-303F
    return "other"


def split_lans(line):
    last_latin = None
    grams = []
    for gram in line:
        if unicode_type(gram) == "latin":
            if last_latin == None or last_latin == False:
                grams.append(gram)
            else:
                grams[-1] += gram
            last_latin = True
        else:
            grams.append(gram)
            last_latin = False
    return grams


def count_word(counter, word, n=1):  # 统计词频  累加n
    if word not in counter:
        counter[word] = n
    else:
        counter[word] += n


def sort_counter(counter, reverse=True):  # 词频降序
    items = sorted(counter.items(), key=lambda kv: kv[1], reverse=reverse)
    counter = dict(items)
    return counter


def counter2frequency(counter):
    sum = 0
    for word, num in counter.items():
        sum += num
    frequency = {}
    for word, num in counter.items():
        frequency[word] = num / sum
    return frequency


def counter2dict(counter, word2index=Default_Dict, min_freq=2, max_token=10000):  # 生成字典
    ignored_word_count = 0
    for word, count in counter.items():
        if len(word2index) >= max_token:
            print("词典已满")
            break
        if word not in word2index:
            if count >= min_freq:
                word2index[word] = len(word2index)
            else:
                ignored_word_count += 1
    print('[Info] 频繁字典大小 = {},'.format(len(word2index)), '最低频数 = {}'.format(min_freq))
    print("[Info] 忽略罕词数 = {}".format(ignored_word_count))
    return word2index


def get_index2word(word2index):
    index2word = []
    for word, count in word2index.items():
        index2word.append(word)
    return index2word


def sentence2indices(line, word2index, max_len=20, padding_index=PAD, unk=UNK, began=None,
                     end=None):
    seq_idx = [word2index.get(word, unk) for word in line]
    seq_idx=seq_idx[:max_len]
    if began is not None:
        seq_idx.insert(0, began)
    if end is not None:
        seq_idx.append(end)

    if max_len is not None and len(seq_idx)<max_len:
        seq_idx += [padding_index] * (max_len - len(seq_idx))
    assert len(seq_idx)==max_len
    return seq_idx

def indices2sentence(index2word, indices):
    sentence = "".join(index2word[index] for index in indices)
    return sentence

def split_train(x, rate=0.90, shuffle=True):
    if shuffle:
        random.shuffle(x)
    index = int(len(x) * rate)
    train = x[:index]
    test = x[index:]
    index = int(len(test) * 0.9)
    valid = test[:index]
    test = test[index:]
    return train, valid, test


def write_splits(x, dir, shuffle=True):
    print("正在划分训练集"+dir)
    if shuffle:
        random.shuffle(x)
    left = int(len(x) * 0.9)
    right = left + int(0.9 * (len(x) - left))

    with open(dir + "/test.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(x[right:]))
    print("测试集已写入")
    with open(dir + "/valid.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(x[left:right]))
    print("验证集已写入")
    with open(dir + "/train.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(x[:left]))
    print("训练集、验证集、测试集已写入", dir, "目录下")


def count_doc(doc, counter={}):
    # for index, line in enumerate(iter(lambda: read_start_of_line(reade_file), '')):
    n_line,n_words=0,0
    for line in doc:
        n_line+=1
        if n_line%10000000==0:
            print("第",n_line,"行")
        words = split_lans(line)
        for word in words:
            if word:
                count_word(counter, word)
            n_words+=len(words)

    print("总计",n_line,"行",n_words,"字")
    return sort_counter(counter)


def merge_counter(counter1, counter2):
    if len(counter1) > 0:
        for word, num in counter1.items():
            count_word(counter2, word, num)
    return sort_counter(counter2)

def collate_fn(insts):
    ''' collate校对  批补齐填充'''
    max_len = max(len(inst) for inst in insts)

    batch_seq = np.array([
        inst + [PAD] * (max_len - len(inst))
        for inst in insts])

    batch_pos = np.array([
        [pos_i+1 if w_i != PAD else 0
         for pos_i, w_i in enumerate(inst)] for inst in batch_seq])

    batch_seq = torch.LongTensor(batch_seq)
    batch_pos = torch.LongTensor(batch_pos)

    return batch_seq, batch_pos

def get_pos(batch):
    src_pos = np.array([
        [pos_i + 1 if w_i != PAD else 0
         for pos_i, w_i in enumerate(line)] for line in batch])
    return torch.LongTensor(src_pos)

def qa_batches(list, batch_size, vocab, max_len, padding_index=PAD, shuffle=True, length_group=True):
    if length_group:
        list.sort(key=lambda x: max(len(l) for l in x.split("\t")))

    for i in range(0, len(list), batch_size):
        batch = list[i:i + batch_size]
        if shuffle:
            random.shuffle(batch)
        q, a = [], []
        for line in batch:
            x,y=line.split("\t")
            q_seq_idx=sentence2indices(line=x, word2index=vocab, max_len=max_len, padding_index=PAD)
            a_seq_idx=sentence2indices(line=y, word2index=vocab, max_len=max_len, padding_index=PAD)
            q.append(q_seq_idx)
            a.append(a_seq_idx)
        yield torch.LongTensor(q).to(device),torch.LongTensor(a).to(device)

def make_batches(list, batch_size, vocab, max_len=20, padding_index=PAD, shuffle=True, length_group=True):
    if length_group:
        list.sort(key=lambda x: len(x[0]))

    for i in range(0, len(list), batch_size):
        batch = list[i:i + batch_size]
        if shuffle:
            random.shuffle(batch)
        x, y = [], []
        for j in range(len(batch)):
            batch[j] = batch[j][:max_len]
            seq_idx, seq_pos=sentence2indices(line=batch[j], word2index=vocab, max_len=20, padding_index=PAD)
            x.append(seq_idx)
            y.append(batch[j][1])
        yield torch.LongTensor(x), torch.LongTensor(y)

def shot_batch(dict_data, n_class, n_support, n_batch,max_len,word2index=None):  # [y][x,x,x,]
    classes = random.sample([x for x in range(len(dict_data))], n_class)
    # 按类选取，标签映射至range(0,n_class)
    labels = {}  # 照此顺序，类内打乱
    for i in range(len(classes)):
        labels[classes[i]] = i

    support_x,support_y=[],[]
    batch_x,batch_y=[],[]

    batch={}
    for c in classes:
        examples=dict_data[c]
        # while n_support + n_batch>len(examples):
        #     examples+=examples
        examples = random.sample(examples, n_support + n_batch)
        for i in range(len(examples)):
            examples[i]=sentence2indices(line=examples[i], word2index=word2index, max_len=max_len, padding_index=PAD)

        for example in examples[0:n_support]:# sample_labels:[0,1,2,3,4]
            support_y.append(labels[c])
            support_x.append(example)

        batch[labels[c]]=examples[n_support:n_support+n_batch]

    for i in range(n_batch):  # batch_labels:[0,1,2,3,4]~19
        for c in range(n_class):
            batch_y.append(c)
            batch_x.append(batch[c][i])

    # samples, sample_labels, batches, batch_labels = [], [], [], []

    samples, sample_labels, batches, batch_labels = torch.LongTensor(support_x), torch.LongTensor(support_y), torch.LongTensor(batch_x), torch.LongTensor(batch_y)
    return  samples.to(device), sample_labels.to(device), batches.to(device), batch_labels.to(device),labels

def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def json_dump(dir,source):
    # path = "/chitchat_data.txt"
    # path = dir+"/chitchat_data.1000.txt"
    path=dir+"/"+source
    name=os.path.abspath(path)
    doc = open(path, "r", encoding="utf-8").read().splitlines()
    print(name+"文件已读取")
    counter = count_doc(doc)
    print(name+"已统计词频")
    with open(dir+"/counter.json", "w", encoding="utf-8") as f:
        json.dump(counter, f, ensure_ascii=False)
    write_splits(doc,dir)
    # dict = counter2dict(counter)
    # print(dict)
    #
    # labels = {}
    # for line in doc:
    #     line = line.split("\t")[0]
    #     if line not in labels:
    #         labels[line] = len(labels)
    # print(len(labels))

def json_load(dir):
    with open(dir + "/counter.json", "r", encoding="utf-8") as f:
        counter = json.load(f)
    vocab = counter2dict(counter=counter,min_freq=2)
    print(vocab)

if __name__ == "__main__":
    t0 = time()
    dir="../data/chitchat_data"
    source="chitchat_data.txt"

    dir="../data/qa_data"
    source="qa_data.txt"


    # dir="../data/chitchat_data.1000"
    # source="chitchat_data.1000.txt"

    # dir="../data/qa_data"
    json_dump(dir,source)
    # json_load(dir)
    print("耗时", time() - t0)
