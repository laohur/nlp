"处理文本"
import argparse
import torch
import transformer.Constants as Constants
from reader import *
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def main(required=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('-source', default=required["source"])
    parser.add_argument('-dir', default=required["dir"])
    parser.add_argument('-save_data', default=required["dir"]+"/reader.pkl")

    parser.add_argument('-max_len', '--max_word_seq_len', type=int, default=20)
    parser.add_argument('-min_word_count', type=int, default=2)
    parser.add_argument('-keep_case', action='store_true', default=False)
    parser.add_argument('-share_vocab', action='store_true', default=required["share_vocab"])
    parser.add_argument('-vocab', default=None)

    args = parser.parse_args()
    args.max_token_seq_len = args.max_word_seq_len + 2  # include the <s> and </s>
    path="../data/ChitChat/chitchat_data.txt"
    reader=Reader()
    doc=reader.read_file(path)
    reader.gen_dict()

    train,valid,test=split_train(doc)
    writeto(train,args.dir+"/"+"train.txt")
    writeto(valid,args.dir+"/"+"valid.txt")
    writeto(test,args.dir+"/"+"test.txt")

    print('[Info] 字典保存训练数据到 ', args.save_data)
    torch.save(reader, args.save_data)
    print('[Info] Finished.')



if __name__ == '__main__':

    #dir="jd"
    #required={
        #"dir":"jd",
        #"train_src": dir+"/train_src.txt",
        #"train_tgt": dir+"train.tgt".txt,
        #"valid_src": dir+"/valid_src.txt",
        #"valid_tgt": dir+"/valid_tgt.txt",
        #"save_data": dir+"/data.pkl"
    #}
    dir="data"
    required={
        "source": "../data/ChitChat/chitchat_data.txt",
        "dir":dir,
        "share_vocab":True
    }    
    main(required)
