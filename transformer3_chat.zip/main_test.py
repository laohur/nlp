# -*- coding: utf-8 -*-
import os
import torch
import torch.utils.data
import argparse
from tqdm import tqdm
from transformer.Translator import Translator
import json
from Util import *

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def main():
    parser = argparse.ArgumentParser(description='main_test.py')
    parser.add_argument('-dir', default="../data/chitchat_data")
    # parser.add_argument('-reader', default=required["dir"]+"/reader.pkl")
    # parser.add_argument('-src', required=True, help='Source test data to decode (one line per sequence)')
    # parser.add_argument('-vocab', required=True,help='Source data to extract vocabs (one line per sequence)')
    # parser.add_argument('-output_dir', required=True, help="Dir to store the decoded outputs")
    parser.add_argument('-model', default="log/model.ckpt", help='模型路径')
    # parser.add_argument('-src', default=required["src"], help='测试集源文件路径')
    parser.add_argument('-output_dir', default="output", help="输出路径")
    parser.add_argument('-max_token_seq_len', default=20)

    parser.add_argument('-beam_size', type=int, default=20, help='Beam size')
    parser.add_argument('-batch_size', type=int, default=16, help='Batch size')
    parser.add_argument('-n_best', type=int, default=3, help="""多句输出""")
    parser.add_argument('-cuda', action='store_true', default=torch.cuda.is_available())

    args = parser.parse_args()
    if not os.path.exists(args.output_dir):
        os.mkdir(args.output_dir)

    with open(args.dir + "/counter.json", "r", encoding="utf-8") as f:
        counter = json.load(f)
    args.vocab = counter2dict(counter=counter, min_freq=2)
    index2word = get_index2word(args.vocab)
    print(args.vocab)

    # Prepare DataLoader
    print("加载数据集")
    test_data = open(args.dir + "/test.txt", "r", encoding="utf-8").read().splitlines()

    test_gener = qa_batches(test_data, batch_size=args.batch_size, vocab=args.vocab, max_len=args.max_token_seq_len,
                            shuffle=False, length_group=False)

    translator = Translator(args)
    path = args.dir + '/test_out.txt'
    with open(path, 'w') as f:
        for batch in tqdm(test_gener, mininterval=2, desc='  - (Test)', leave=False, total=int(len(test_data)/args.batch_size)):
            src_seq,  tgt_seq = batch
            src_seq,  tgt_seq = src_seq.to(device), tgt_seq.to(device)
            all_hyp, all_scores = translator.translate_batch(src_seq)
            for idx_seqs in all_hyp:
                for idx_seq in idx_seqs:
                    pred_line = ' '.join([index2word[idx] for idx in idx_seq])
                    f.write(pred_line + '\n')
    print('[Info] 测试完成，文件写入' + path)


if __name__ == "__main__":

    main()
