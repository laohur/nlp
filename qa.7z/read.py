
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.autograd import Variable
import matplotlib.pyplot as plt
dtype = torch.FloatTensor

# d_model = 512  # Embedding Size
d_model = 256  # Embedding Size
# d_ff = 2048 # FeedForward dimension
d_ff = 1024 # FeedForward dimension
d_k = d_v = 64  # dimension of K(=Q), V
n_layers = 6  # number of Encoder of Decoder Layer
n_heads = 8  # number of heads in Multi-Head Attention

class Corpus():
    '''
    [PAD]	0
    [CLS]	1
    [SEP]	2
    [MASK]	3
    α	0
    β	1
    γ	2
    δ	3
    '''

    def __init__(self):
        self.half_len=5
        self.Pad="α"
        self.Head="β"
        self.Tail="δ"
        # self.vocab=set()
        self.word2index={}
        self.index2word=[]
        self.sources=[]
        self.outputs=[]
        self.targets=[]

    def read_dict(self,path="data/vocab.txt"):
        with open(path, mode="r", encoding="utf8") as f:
            line_count = 0
            for row in f.readlines():
                word=row.split("\t")[0]
                word=word.replace("##","")
                # self.vocab.add(word)
                self.add_word(word)
                # index=int(index)
                # self.word2index[word]= index
                # self.index2word.append(word)
                line_count += 1
                # if line_count%100==0:
                #     print(word,index)

        print(path+"中读取了",line_count,"word2index len:",len(self.word2index)," index2word len:",len(self.index2word))

    def add_word(self,word):
        if word not in self.word2index.keys():
            self.index2word.append(word)
            self.word2index[word]=len(self.word2index)

    def get_dict(self):
        print("index2word len",len(self.index2word), "word2index",len(self.word2index))
        for i in range(len(self.index2word)):
            assert i==self.word2index[self.index2word[i]]
        return self.word2index, self.index2word


    def padding(self,sentence):
        if len(sentence)<self.half_len*2:
            sentence+=self.Pad*(self.half_len*2-len(sentence))


        if len(sentence)>self.half_len*2:
            # print(len(sentence))
            # print(len(sentence[0:self.half_len]))
            # print(len(sentence[len(sentence)-self.half_len:len(sentence)]))
            sentence=sentence[0:self.half_len]+sentence[len(sentence)-self.half_len:len(sentence)]
            # print(len(sentence))
        assert len(sentence)==self.half_len*2

        return sentence


    def read_corpus(self,path="data/all-anon.skuqa"):
        with open(path, mode="r", encoding="utf8") as f:
            line_count = 0
            qlenth=0
            alenth=0
            multi_count=0
            for row in f.readlines():
                for word in row:
                    # self.vocab.add(word)
                    self.add_word(word)

                words=row.split("\t")
                if len(words)<=2:
                    continue
                qlenth+=len(words[1])
                alenth+=len(words[2])
                source=self.padding(pure(words[1]))
                output=self.padding(self.Head+pure(words[2]))
                target=self.padding(pure(words[2])+self.Tail)

                # print("\n words",words)
                # print("source",source)
                # print("output",output)
                # print("target",target)

                self.sources.append(source)
                self.outputs.append(output)
                self.targets.append(target)

                if len(words)>3:
                    multi_count+=1
                line_count += 1
                # if line_count%100==0:
                #     print(words[1],words[2],line_count)

        print(path+"中读取了",line_count,"问答有",len(self.sources),"对话的有",multi_count,"平均问题长",qlenth/len(self.sources),"平均回答长",alenth/len(self.sources))
        # print(word2index)
        return self.sources,self.outputs,self.targets

    def sentence2indices(self, line):
        return [self.word2index[word] for word in list(line)]

    def indices2sentence(self, indices):
        sentence="".join(self.index2word[index] for index in indices)
        return sentence

    def digitize(self, origin):
        batch=[]
        for line in origin:
            # print(line)
            batch.append(self.sentence2indices(line))
        # print(batch[0])
        # print( Variable(torch.LongTensor(batch)).shape)
        return Variable(torch.LongTensor(batch))

    def batch(self):
        return self.digitize(self.sources), self.digitize(self.outputs), self.digitize(self.targets)

def pure(line):
        import re
        return re.sub(u"([^\u4e00-\u9fa5\u0030-\u0039\u0041-\u005a\u0061-\u007a])", "", line)
        # 去除特殊字符，只保留汉子，字母、数字
        import re
        # string = "123我123456abcdefgABCVDFF？/ ，。,.:;:''';'''[]{}()（）《》"
        # print(string)
        # 123
        # 我123456abcdefgABCVDFF？ / ，。, .:;:''';'''[]
        # {}()（）《》
        # sub_str = re.sub(u"([^\u4e00-\u9fa5\u0030-\u0039\u0041-\u005a\u0061-\u007a])", "", string)
        # print(sub_str)
        # 123
        # 我123456abcdefgABCVDFF

def make_batch():
    corpus = Corpus()
    corpus.read_dict("data/vocab.txt")
    corpus.read_corpus("data/all-anon.skuqa.1000")
    # vocab={word:index for word,index in enumerate(corpus.vocab)  }
    # number_dict={index:word for word,index in enumerate(corpus.vocab)  }
    vocab,number_dict=corpus.get_dict()
    print(vocab)
    print(number_dict)
    src_vocab=tgt_vocab=vocab
    enc_inputs, dec_inputs, target_batch = corpus.batch()
    # for i in range(len(enc_inputs)):
    #     print("问题",i,corpus.indices2sentence(enc_inputs[i]))
    #     print("解码输入",corpus.indices2sentence(dec_inputs[i]))
    #     print("回答",corpus.indices2sentence(target_batch[i]))

    return corpus.batch()

make_batch()