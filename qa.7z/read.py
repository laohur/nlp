
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.autograd import Variable
import matplotlib.pyplot as plt

dtype = torch.FloatTensor

# d_model = 512  # Embedding Size
d_model = 256  # Embedding Size
# d_ff = 2048 # FeedForward dimension
d_ff = 1024 # FeedForward dimension
d_k = d_v = 64  # dimension of K(=Q), V
n_layers = 6  # number of Encoder of Decoder Layer
n_heads = 8  # number of heads in Multi-Head Attention

class Corpus():
    '''
    [PAD]	0
    [CLS]	1
    [SEP]	2
    [MASK]	3
    α	0
    β	1
    γ	2
    δ	3
    '''

    def __init__(self):
        self.half_len=20
        self.Pad="α"
        self.Head="β"
        self.Tail="δ"
        self.vocab=set()
        self.word2index={}
        self.index2word=[]
        self.sources=[]
        self.outputs=[]
        self.targets=[]

    def read_dict(self,path="data/vocab.txt"):
        with open(path, mode="r", encoding="utf8") as f:
            line_count = 0
            for row in f.readlines():
                word,index=row.split("\t")
                word=word.replace("##","")
                self.vocab.add(word)
                # index=int(index)
                # self.word2index[word]= index
                # self.index2word.append(word)
                line_count += 1
                # if line_count%100==0:
                #     print(word,index)

        print(path+"中读取了",line_count)
        # print(word2index)

    def get_dict(self):
        self.word2index = {index: word for word, index in enumerate(self.vocab)}
        self.index2word= {word: index for word, index in enumerate(self.vocab)}
        return self.word2index,self.index2word

    def padding(self,sentence):
        if len(sentence)<self.half_len*2:
            sentence+=self.Pad*(self.half_len*2-len(sentence))


        if len(sentence)>self.half_len*2:
            # print(len(sentence))
            # print(len(sentence[0:self.half_len]))
            # print(len(sentence[len(sentence)-self.half_len:len(sentence)]))
            sentence=sentence[0:self.half_len]+sentence[len(sentence)-self.half_len:len(sentence)]
            # print(len(sentence))
        assert len(sentence)==self.half_len*2

        return sentence

    def read_corpus(self,path="data/all-anon.skuqa"):
        with open(path, mode="r", encoding="utf8") as f:
            line_count = 0
            qlenth=0
            alenth=0
            multi_count=0
            for row in f.readlines():
                words=row.split("\t")
                if len(words)<=2:
                    continue
                qlenth+=len(words[1])
                alenth+=len(words[2])
                source=self.padding(words[1])
                output=self.padding(self.Head+words[2])
                target=self.padding(words[2]+self.Tail)
                self.sources.append(source)
                self.outputs.append(output)
                self.targets.append(target)
                for word in row:
                    self.vocab.add(word)
                    # self.add_word(char)
                if len(words)>3:
                    multi_count+=1
                line_count += 1
                # if line_count%100==0:
                #     print(words[1],words[2],line_count)

        print(path+"中读取了",line_count,"问答有",len(self.sources),"对话的有",multi_count,"平均问题长",qlenth/len(self.sources),"平均回答长",alenth/len(self.sources))
        # print(word2index)
        return self.sources,self.outputs,self.targets

    def digitize(self, origin):
        batch=[]
        for line in origin:
            # print(line)
            batch.append([self.word2index[word] for word in list(line)])
        # print(batch[0])
        # print( Variable(torch.LongTensor(batch)).shape)
        return Variable(torch.LongTensor(batch))

    def batch(self):
        return self.digitize(self.sources), self.digitize(self.outputs), self.digitize(self.targets)

def make_batch():
    corpus = Corpus()
    corpus.read_dict("data/vocab.txt")
    corpus.read_corpus("data/all-anon.skuqa.1000")
    # vocab={word:index for word,index in enumerate(corpus.vocab)  }
    # number_dict={index:word for word,index in enumerate(corpus.vocab)  }
    vocab,number_dict=corpus.get_dict()
    print(vocab)
    print(number_dict)
    src_vocab=tgt_vocab=vocab
    return corpus.batch()

make_batch()