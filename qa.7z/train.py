
import numpy as np
import math
import torch
import torch.nn as nn
import torch.optim as optim
from torch.autograd import Variable
import torch.nn.functional as F
import matplotlib.pyplot as plt
from mytransformer import Transformer

dtype = torch.FloatTensor
# S: Symbol that shows starting of decoding input
# E: Symbol that shows starting of decoding output
# P: Symbol that will fill in blank sequence if current batch data size is short than time steps
sentences = ['ich mochte ein bier P', 'S i want a beer', 'i want a beer E']

# Transformer Parameters
src_vocab = {'PAD' : 0}
for i, w in enumerate(sentences[0].split()):
    src_vocab[w] = i+1
src_vocab_size = len(src_vocab)

tgt_vocab = {'PAD' : 0}
number_dict = {0 : 'PAD'}
for i, w in enumerate(set((sentences[1]+' '+sentences[2]).split())):
    tgt_vocab[w] = i+1
    number_dict[i+1] = w
tgt_vocab_size = len(tgt_vocab)

vocab_size = 18000 #使用百度ERNIE字典
src_len = 50 #输入序列长度
tgt_len = 50 #输出序列长度

d_model = 512  # Embedding Size
d_ff = 2048 # FeedForward dimension
d_k = d_v = 64  # dimension of K(=Q), V
n_layers = 6  # number of Encoder of Decoder Layer
n_heads = 8  # number of heads in Multi-Head Attention

def make_batch():
    dir="data"
    qa_path=dir+"/all-anon.skuqa"
    vocab_path =dir+ "vocab.txt"
    src_vocab=vocab
    tgt_vocab=vocab
    input_batch = [[src_vocab[n] for n in sentences[0].split()]]
    output_batch = [[tgt_vocab[n] for n in sentences[1].split()]]
    target_batch = [[tgt_vocab[n] for n in sentences[2].split()]]
    return Variable(torch.LongTensor(input_batch)), Variable(torch.LongTensor(output_batch)), Variable(torch.LongTensor(target_batch))

model = Transformer()

#criterion = nn.CrossEntropyLoss()
def LabelSmoothing(smoothing,x,target,padding_idx=0):
    size=x.size(1)
    true_dist = x.data.clone()
    true_dist.fill_(smoothing / (size - 2))
    true_dist.scatter_(1, target.data.unsqueeze(1), (1-smoothing))
    true_dist[:, padding_idx] = 0
    mask = torch.nonzero(target.data == padding_idx)
    if mask.dim() > 0:
        true_dist.index_fill_(0, mask.squeeze(), 0.0)
    criterion = nn.KLDivLoss(size_average=False)
    return criterion(x, Variable(true_dist, requires_grad=False))

def criterion(smoothing,x,target,padding_idx=0):
    return LabelSmoothing(smoothing,x,target,padding_idx=0)

optimizer = optim.Adam(model.parameters(), lr=0.001)

def wave_lr(step, max_step, cycle, max_lr):
    sub =step%cycle
    if sub<20:
        sub = sub/20
    else:
        sub = 1-sub/100
    level = 1-step/max_step

    weight = math.sqrt(level)+math.pow(sub,2)
    return weight*max_lr

for epoch in range(100):
    optimizer.zero_grad()
    enc_inputs, dec_inputs, target_batch = make_batch(sentences)
    outputs, enc_self_attns, dec_self_attns, dec_enc_attns = model(enc_inputs, dec_inputs)
    loss = criterion(outputs, target_batch.contiguous().view(-1))
    if (epoch + 1) % 20 == 0:
        print('Epoch:', '%04d' % (epoch + 1), 'cost =', '{:.6f}'.format(loss))
    loss.backward()
    optimizer.step()

def showgraph(attn):
    attn = attn[-1].squeeze(0)[0]
    attn = attn.squeeze(0).data.numpy()
    fig = plt.figure(figsize=(n_heads, n_heads)) # [n_heads, n_heads]
    ax = fig.add_subplot(1, 1, 1)
    ax.matshow(attn, cmap='viridis')
    ax.set_xticklabels(['']+sentences[0].split(), fontdict={'fontsize': 14}, rotation=90)
    ax.set_yticklabels(['']+sentences[2].split(), fontdict={'fontsize': 14})
    plt.show()

# Test
predict, _, _, _ = model(enc_inputs, dec_inputs)
predict = predict.data.max(1, keepdim=True)[1]
print(sentences[0], '->', [number_dict[n.item()] for n in predict.squeeze()])

print('first head of last state enc_self_attns')
showgraph(enc_self_attns)

print('first head of last state dec_self_attns')
showgraph(dec_self_attns)

print('first head of last state dec_enc_attns')
showgraph(dec_enc_attns)