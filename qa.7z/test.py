import torch
from torch import nn

class Encoder(nn.Module):
    def __init__(self):
        super(Encoder, self).__init__()
        self.src_emb = nn.Embedding(10000, 512)
        # self.pos_emb = nn.Embedding.from_pretrained(get_sinusoid_encoding_table(src_len+1 , d_model),freeze=True)
        # self.pos_emb = nn.Embedding.from_pretrained(get_sinusoid_encoding_table(src_len , d_model),freeze=True)
        # self.layers = nn.ModuleList([EncoderLayer() for _ in range(n_layers)])

    def forward(self, enc_inputs): # enc_inputs : [batch_size x source_len]
        # enc_outputs = self.src_emb(enc_inputs) + self.pos_emb(torch.LongTensor([[1,2,3,4,5]]))
        print("enc_inputs shape",enc_inputs.shape)
        batch_size=enc_inputs.shape[0]
        # pos0=[i for i in range(1,corpus.half_len*2+1)]
        # pos=[pos0]*batch_size
        # pos=torch.LongTensor(pos)
        # print("pos shape",pos.shape)
        # print("self.pos_emb(pos) shape",self.pos_emb(pos).shape)
        print("self.src_emb(enc_inputs) shape",self.src_emb(enc_inputs).shape)
        # enc_outputs = self.src_emb(enc_inputs) + self.pos_emb(pos)
        # # enc_outputs = self.src_emb(enc_inputs) + self.pos_emb(torch.LongTensor([[i for i in range(1,corpus.half_len*2+1)]]))
        # enc_self_attn_mask = padding_mask(enc_inputs, enc_inputs)
        # enc_self_attns = []
        # for layer in self.layers:
        #     enc_outputs, enc_self_attn = layer(enc_outputs, enc_self_attn_mask)
        #     enc_self_attns.append(enc_self_attn)
        # return enc_outputs, enc_self_attns
        return self.src_emb(enc_inputs)

encoder =Encoder()
inputs=torch.randint(low=0,high=1000,size=(1000,40))

outputs=encoder(inputs)

print(outputs)