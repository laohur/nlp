[PAD]	0 α
[CLS]	1 β
[SEP]	2 γ
[MASK]	3 δ

α 0
β 1
γ 2
δ 3




希臘字母 (Greek Alphabets)

大寫
	

小寫
	

讀音
	

大寫
	

小寫
	

讀音
	

大寫
	

小寫
	

讀音

Α
	

α
	

alpha
	

Ι
	

ι
	

iota
	

Ρ
	

ρ
	

rho

Β
	

β
	

beta
	

Κ
	

κ
	

kappa
	

Σ
	

σ, ς
	

sigma

Γ
	

γ
	

gamma
	

Λ
	

λ
	

lambda
	

Τ
	

τ
	

tau

Δ
	

δ
	

delta
	

Μ
	

μ
	

mu
	

Υ
	

υ
	

upsilon

Ε
	

ε
	

epsilon
	

Ν
	

ν
	

nu
	

Φ
	

φ
	

phi

Ζ
	

ζ
	

zeta
	

Ξ
	

ξ
	

xi
	

Χ
	

χ
	

khi

Η
	

η
	

eta
	

Ο
	

ο
	

omicron
	

Ψ
	

ψ
	

psi

Θ
	

θ
	

theta
	

Π
	

π
	

pi
	

Ω
	

ω
	

omega

背景音樂: [生命交響曲, 貝多芬]
上次網頁修改日期: 2001/10/05