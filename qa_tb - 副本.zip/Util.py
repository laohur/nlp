"处理文本"
import argparse
import torch
import transformer.Constants as Constants
import json
import math
from time import time
import os
from dataset import SeqDataset, paired_collate_fn

def unicode_type(unicode):  # 判断字符类型
    # https://gist.github.com/shingchi/64c04e0dd2cbbfbc1350
    if ord(unicode) <= 0x007f:  # ascii
        if ord(unicode) >= 0x0041 and ord(unicode) <= 0x005a:
            return "latin"
        if ord(unicode) >= 0x0061 and ord(unicode) <= 0x007a:
            return "latin"
        return "ascii_symble"
    if ord(unicode) >= 0x4E00 and ord(unicode) <= 0x9fff:
        return "han"  # 标准CJK文字
    if ord(unicode) >= 0xFF00 and ord(unicode) <= 0xFFEF:
        return "han_symble"  # 全角ASCII、全角中英文标点、半宽片假名、半宽平假名、半宽韩文字母：FF00-FFEF
    if ord(unicode) >= 0x3000 and ord(unicode) <= 0x303F:
        return "han_symble"  # CJK标点符号：3000-303F
    return "other"

def pure(line):
    re=[]
    for w in line:
        if unicode_type(w)=="other":
            continue
        re.append(w)
    return "".join(re)

def load_file(inst_file, max_sent_len, keep_case=False, begin=0, end=-1):
    if end < 0:
        end = math.inf
    if "vocab" in inst_file:
        print("vocab", inst_file)
    ''' 由文本生成词典和序列 '''
    word_insts = []
    trimmed_sent_count = 0
    t0 = time()
    print("正在读取", os.path.abspath(inst_file), begin, "->", end)
    doc = open(inst_file, "r", encoding="utf-8").read().splitlines()
    for i in range(len(doc)):
        if i < begin:
            continue
        if i > end:
            break
        sent = doc[i]
        if not keep_case:
            sent = sent.lower()
        words = sent.split()
        if len(words) > max_sent_len:
            # if len(words)>max_sent_len*9:
            # print("过长被截断",len(words),words)
            trimmed_sent_count += 1
        # 左截断，左右各一半更好
        word_inst = words[:max_sent_len]
        line = [[Constants.BOS_WORD] + word_inst + [Constants.EOS_WORD]] if word_inst else [None]
        word_insts += line
        if i % 1000000 == 0:
            print("进展", i * 100.0 / len(doc), "第", i, "行", line)
    print('[Info] ""文件{}中获取{}句子'.format(inst_file, len(word_insts)))

    if trimmed_sent_count > 0:
        print('[Warning] {}个句子被截断至最大长度{}.'.format(trimmed_sent_count, max_sent_len))

    return word_insts


def build_vocab_idx(word_insts, min_word_count, max_words=50000):
    ''' Trim vocab by number of occurence '''

    full_vocab = set(w for sent in word_insts for w in sent)
    print('[Info] 原始词库 =', len(full_vocab))

    word2idx = {
        Constants.BOS_WORD: Constants.BOS,
        Constants.EOS_WORD: Constants.EOS,
        Constants.PAD_WORD: Constants.PAD,
        Constants.UNK_WORD: Constants.UNK}

    word_count = {w: 0 for w in full_vocab}

    for sent in word_insts:
        for word in sent:
            word_count[word] += 1
    word_count = dict(sorted(word_count.items(), key=lambda kv: kv[1], reverse=True))

    ignored_word_count = 0
    for word, count in word_count.items():
        if len(word2idx) >= max_words:
            print("[!]词典已满", len(word2idx))
            break
        if word not in word2idx:
            if count >= min_word_count:
                word2idx[word] = len(word2idx)
            else:
                ignored_word_count += 1

    frequency = {}
    for word, idx in word2idx.items():
        if idx < 4:
            frequency[idx] = -1
        elif word in word_count:
            frequency[idx] = word_count[word]

    print('[Info] 频繁字典大小 = {},'.format(len(word2idx)), '最低频数 = {}'.format(min_word_count))
    print("[Info] 忽略罕词数 = {}".format(ignored_word_count))
    return word2idx, frequency


def convert_w2id_seq(word_insts, word2idx):
    ''' Mapping words to idx sequence. '''
    return [[word2idx.get(w, Constants.UNK) for w in s] for s in word_insts]


def prepare_dataloaders(data, args):
    train_loader = torch.utils.data.DataLoader(
        SeqDataset(
            src_word2idx=data['dict']['src'],
            tgt_word2idx=data['dict']['tgt'],
            src_insts=data['train']['src'],
            tgt_insts=data['train']['tgt']),
        num_workers=4,
        batch_size=args.batch_size,
        collate_fn=paired_collate_fn,
        shuffle=True)

    valid_loader = torch.utils.data.DataLoader(
        SeqDataset(
            src_word2idx=data['dict']['src'],
            tgt_word2idx=data['dict']['tgt'],
            src_insts=data['valid']['src'],
            tgt_insts=data['valid']['tgt']),
        num_workers=4,
        batch_size=args.batch_size,
        collate_fn=paired_collate_fn)
    return train_loader, valid_loader
