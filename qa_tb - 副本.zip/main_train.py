# -*- coding: utf-8 -*-
import os
import argparse
import torch
import torch.utils.data
from transformer.Models import Transformer
from transformer.Optim import ScheduledOptim
# from trainer import train
from trainer import train
import json
from Util import *


def main():
    parser = argparse.ArgumentParser(description='main_train.py')
    parser.add_argument('-data_dir', default="data")
    parser.add_argument('-epoch', type=int, default=30)
    parser.add_argument('-batch_size', type=int, default=32)
    parser.add_argument('-d_word_vec', type=int, default=512)
    parser.add_argument('-d_model', type=int, default=512)
    parser.add_argument('-d_inner_hid', type=int, default=2048)
    parser.add_argument('-d_k', type=int, default=64)
    parser.add_argument('-d_v', type=int, default=64)
    parser.add_argument('-n_head', type=int, default=8)
    parser.add_argument('-n_layers', type=int, default=6)
    parser.add_argument('-n_warmup_steps', type=int, default=4000)
    parser.add_argument('-dropout', type=float, default=0.1)
    parser.add_argument('-embs_share_weight', action='store_true', default=True)
    parser.add_argument('-proj_share_weight', action='store_true', default=True)
    parser.add_argument('-label_smoothing', action='store_true', default=True)
    parser.add_argument('-log', default="log")
    parser.add_argument('-save_model', default="model")
    parser.add_argument('-save_mode', type=str, choices=['all', 'best'], default='best')
    parser.add_argument('-cuda', action='store_true', default=torch.cuda.is_available())

    args = parser.parse_args()
    if not os.path.exists(args.log):
        os.mkdir(args.log)

    print("加载词汇表")
    with open(args.data_dir+"/reader.json", "r", encoding="utf-8") as f:
        reader = json.load(f)
    args.max_token_seq_len = reader['settings']["max_token_seq_len"]

    print("加载训练数据")
    data = torch.load(args.data_dir+"/train.data")

    training_data, validation_data = prepare_dataloaders(data, args)

    args.src_vocab_size = training_data.dataset.src_vocab_size
    args.tgt_vocab_size = training_data.dataset.tgt_vocab_size

    print("准备模型")
    if args.embs_share_weight:
        assert training_data.dataset.src_word2idx == training_data.dataset.tgt_word2idx, \
            'The src/tgt word2idx table 不同 但共用word embedding.'

    print(args)

    device = torch.device('cuda' if args.cuda else 'cpu')
    transformer = Transformer(
        args.src_vocab_size,
        args.tgt_vocab_size,
        args.max_token_seq_len,
        tgt_emb_prj_weight_sharing=args.proj_share_weight,
        emb_src_tgt_weight_sharing=args.embs_share_weight,
        d_k=args.d_k,
        d_v=args.d_v,
        d_model=args.d_model,
        d_word_vec=args.d_word_vec,
        d_inner=args.d_inner_hid,
        n_layers=args.n_layers,
        n_head=args.n_head,
        dropout=args.dropout).to(device)

    args.model_path = "log/model.ckpt"
    if os.path.exists(args.model_path):
        checkpoint = torch.load(args.model_path, map_location=device)
        model_opt = checkpoint['settings']
        model = Transformer(
            model_opt.src_vocab_size,
            model_opt.tgt_vocab_size,
            model_opt.max_token_seq_len,
            tgt_emb_prj_weight_sharing=model_opt.proj_share_weight,
            emb_src_tgt_weight_sharing=model_opt.embs_share_weight,
            d_k=model_opt.d_k,
            d_v=model_opt.d_v,
            d_model=model_opt.d_model,
            d_word_vec=model_opt.d_word_vec,
            d_inner=model_opt.d_inner_hid,
            n_layers=model_opt.n_layers,
            n_head=model_opt.n_head,
            dropout=model_opt.dropout)
        model.load_state_dict(checkpoint['model'])
        transformer = model.to(device)
        print('[Info] 装入模型，继续训练')

    args_optimizer = ScheduledOptim(
        torch.optim.Adam(
            filter(lambda x: x.requires_grad, transformer.parameters()),
            betas=(0.9, 0.98), eps=1e-03),
        args.d_model, args.n_warmup_steps)

    train(transformer, training_data, validation_data, args_optimizer, device, args)


if __name__ == '__main__':
    main()
