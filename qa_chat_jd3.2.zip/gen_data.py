import argparse
import torch
import os
from time import time
import random
from Util import *


def char_type(c):  # 判断字符类型
    # https://gist.github.com/shingchi/64c04e0dd2cbbfbc1350
    if ord(c) <= 0x007f:  # ascii
        if ord(c) >= 0x0030 and ord(c) <= 0x0039:
            return "number"
        if ord(c) >= 0x0041 and ord(c) <= 0x005a:
            return "latin"
        if ord(c) >= 0x0061 and ord(c) <= 0x007a:
            return "latin"
        return "ascii_symble"
    if ord(c) >= 0x4E00 and ord(c) <= 0x9fff:
        return "han"  # 标准CJK文字
    if ord(c) >= 0xFF00 and ord(c) <= 0xFFEF:
        return "han_symble"  # 全角ASCII、全角中英文标点、半宽片假名、半宽平假名、半宽韩文字母：FF00-FFEF
    if ord(c) >= 0x3000 and ord(c) <= 0x303F:
        return "han_symble"  # CJK标点符号：3000-303F
    return "other"


def split_lans(line):
    last_latin = None
    grams = []
    for gram in line:  # 还是字符串形式
        if char_type(gram) == "latin":
            if last_latin == None or last_latin == False:
                grams.append(gram)
            else:
                grams[-1] += gram
            last_latin = True
        else:
            grams.append(gram)
            last_latin = False
    return grams


def merge_gram(line):
    last_type = None
    tokens = []
    for gram in line:
        if char_type(gram) == "latin":
            if last_type == "latin":
                tokens[-1] += gram
            else:
                tokens.append(gram)
        elif char_type(gram) == "number":
            if last_type == "number":
                tokens[-1] += gram
            else:
                tokens.append(gram)
        else:
            if gram not in [None, '', ' ']:
                tokens.append(gram)
        last_type = char_type(gram)
    return tokens


def tokenize(line):
    # return list(line)
    # return line.split(" ")
    # words = line.split()
    # line = ''.join(line.split(" "))
    # words = split_lans(line)
    words = merge_gram(line)
    # line = ' '.join(words)
    # words = line.split(" ")
    re = []
    for word in words:
        if len(word) > 7:
            continue
        if word:
            re.append(word)
    return re


def tb_pair(row):
    words = row.split("\t")
    # 数据多，出错丢弃.如果数据出错，前面几段都归为问题，最后一个归为回答.
    if len(words) < 3 or int(words[0]) != 1:
        return None, None
    question = words[1].strip()
    answer = words[2].strip()

    question = " ".join(tokenize(question))
    answer = " ".join(tokenize(answer))

    if len(question) < 2 or len(answer) < 2:
        print("tb_pair字太少", row)
        return None, None
    return question, answer


def get_jdpair(row):
    '''
        full_doc = ["skuid \t attributes \t review  \t counter \t question \t answer"]
    '''
    sents = row.split("\t")
    if len(sents) != 6:
        return None, None, None
    # question = pure(sents[0].strip())
    # answer = pure(sents[1].strip())
    question = sents[4].strip()
    answer = sents[5].strip()
    attr = sents[1].strip()

    question = " ".join(tokenize(question))
    answer = " ".join(tokenize(answer))
    attr = " ".join(tokenize(attr))

    # if len(question) < 1 or len(answer) < 1:
    #     print("get_pair字太少", row)
    #     return None, None
    return question, answer, attr


def get_pair(row):
    sents = row.split("\t")
    if len(sents) < 2:
        return None, None
    # question = pure(sents[0].strip())
    # answer = pure(sents[1].strip())
    question = sents[0].strip()
    answer = sents[1].strip()

    question = " ".join(tokenize(question))
    answer = " ".join(tokenize(answer))

    # if len(question) < 1 or len(answer) < 1:
    #     print("get_pair字太少", row)
    #     return None, None
    return question, answer


def read(path, begin=0, end=-1):
    t0 = time()
    print("read正在读取", os.path.abspath(path))
    doc = open(path, "r", encoding="utf-8").read().splitlines()
    random.shuffle(doc)
    if end < 0:
        end = len(doc)
    print(time() - t0, "秒读出", len(doc), "条")
    t0 = time()
    qlenth, alenth, tlenth = 0, 0, 0  # 问题长度
    questions, answers, attrs = [], [], []
    for i in range(len(doc)):
        if i < begin:
            continue
        if i > end:
            break
        row = doc[i]
        # question, answer = tb_pair(row)
        # question, answer = get_pair(row)
        question, answer, attr = get_jdpair(row)
        if question == None or answer == None or attr == None:
            continue

        qlenth += len(question)
        alenth += len(answer)
        tlenth += len(attr)
        questions.append(question)
        answers.append(answer)
        attrs.append(attr)

        if i % 100000 == 0:
            print("进展", i * 100.0 / (end - begin), "第", i, "行", question, "--->", answer, "<---", attr)

    assert len(answers) == len(questions)
    print(str(path) + "总计", len(doc), "行，有效问答有" + str(len(answers)))
    print("平均问题长", qlenth / len(questions), "平均回答长", alenth / len(answers), "平均详情长", tlenth / len(attrs))
    print(time() - t0, "秒处理", len(answers), "条")
    return questions, answers, attrs


def split_test(path):
    t0 = time()
    print("read正在读取", os.path.abspath(path))
    doc = open(path, "r", encoding="utf-8").read().splitlines()
    random.shuffle(doc)
    print(time() - t0, "秒读出", len(doc), "条")
    splits_write(doc, dir="data", suffix=".txt")


def main():
    # dir = "../data/tb"
    # source = "/train.txt"

    # dir = "../data/qa_data"
    # source = "qa_data.txt"

    # dir = "../data/chitchat_data"
    # source = "chitchat_data.txt"

    # dir = "../data/all"
    # source = "balance.txt"

    dir = "../data/jd"
    source = "full.skuqa"

    split_test(dir + "/" + source)
    names = ["train", "valid", "test"]
    marks = ["src", "tgt", "attr"]
    for name in names:
        result = read("data/" + name + ".txt", begin=0, end=-1)
        for i in range(3):
            path = "data/" + name + "_" + marks[i] + ".txt"
            with open(path, "w", encoding="utf-8") as f:
                f.write("\n".join(result[i]))
            print(" 已写入", os.path.abspath(path))

    # questions, answers, attrs = read(dir + "/" + source, begin=0, end=-1)
    # splits_write(questions, dir="data", suffix="_src.txt")
    # splits_write(answers, dir="data", suffix="_tgt.txt")
    # splits_write(attrs, dir="data", suffix="_attr.txt")


if __name__ == '__main__':
    t0 = time()
    main()
    print(time() - t0, "秒执行完main()")

'''
../data/jd//full.skuqa总计 1685750 行，有效问答有300001
平均问题长 27.155192816023945 平均回答长 21.655607814640618 平均详情长 176.3915820280599
27.85947823524475 秒处理 300001 条


 read正在读取 /home/cs/data/jd/full.skuqa
5.7054054737091064 秒读出 1685750 条
splits_write正在划分训练集 /home/cs/qa_chat_jd3.1/data
测试集已写入
验证集已写入
训练集、验证集、测试集已写入 /home/cs/qa_chat_jd3.1/data 目录下
read正在读取 /home/cs/qa_chat_jd3.1/data/train.txt
5.794355869293213 秒读出 1684750 条
进展 0.0 第 0 行 还 有 没 有 比 49 . 9 更 便 宜 的 ？ ---> 什 么 意 思 ？ 我 149 买 的 <--- 普 通 手 洗 机 洗 国 产 瓶 装 其 它 3 kg 以 上 花 香 去 污 / 去 渍 其 它 好 爸 爸 天 然 薰 香 洗 衣 液 2 . 38 kg × 2 瓶 亲 肤 无 刺 激 广 东 广 州 家 庭 清 洁 / 纸 品 衣 物 清 洁 洗 衣 液
进展 5.935598753524261 第 100000 行 用 电 量 怎 么 样 ， 保 温 一 天 ---> 您 好 ， 详 情 请 联 系 在 线 客 服 咨 询 ， 谢 谢 <--- 健 康 抑 菌 预 约 洗 浴 双 管 加 热 大 屏 数 显 速 热 增 容 一 级 能 效 安 装 费 200 元 封 顶 遥 控 式 储 水 式 电 热 水 器 多 功 率 加 热 炫 彩 机 身 无 线 遥 控 80 - 99 升 一 级 能 效 万 和 （ Vanward ） 80 升 健 康 抑 菌 一 级 能 效 8 年 质 保 智 能 遥 控 双 管 速 热 电 热 水 器 E 80 - Q 3 JY 11 - 21 中 国 大 陆 家 用 电 器 厨 卫 大 电 电 热 水 器
进展 11.871197507048523 第 200000 行 你 好 支 架 拉 出 长 度 是 多 少 ---> 30 多 厘 米 <--- 气 压 式 电 视 挂 架 电 视 配 件 上 下 调 节 电 视 挂 架 摇 臂 电 视 挂 架 NB F 350 （ 40 - 50 英 寸 ) 电 视 挂 架 电 视 架 电 视 支 架 旋 转 伸 缩 气 弹 簧 上 下 升 降 夏 普 飞 利 浦 海 信 40 / 43 / 48 / 49 / 50 / 42 银 色 暂 无 信 息 中 国 大 陆 家 用 电 器 大 家 电 家 电 配 件
进展 17.806796260572785 第 300000 行 开 机 会 播 放 广 告 吗 ？ ---> 没 有 <--- Android 多 屏 互 动 健 康 本 地 播 放 游 戏 购 物 点 播 教 育 小 米 （ MI ） 小 米 盒 子 4 C 智 能 网 络 电 视 机 顶 盒 4 K 电 视 H . 265 硬 解 安 卓 网 络 盒 子 高 清 网 络 播 放 器 HDR 黑 色 中 国 大 陆 电 脑 、 办 公 网 络 产 品 网 络 盒 子
进展 23.742395014097045 第 400000 行 你 们 买 的 都 是 多 长 时 间 到 ？ ---> 大 概 两 周 多 吧 <--- 进 口 藻 油 100 - 199 元 瓶 装 胶 囊 其 它 6 个 月 以 上 澳 洲 原 装 进 口 Bio island 佰 澳 朗 德 比 奥 岛 DHA 孕 妇 海 藻 油 胶 囊 澳 大 利 亚 母 婴 营 养 辅 食 DHA
进展 29.67799376762131 第 500000 行 这 是 正 品 吗 ？ 如 果 不 是 怎 么 办 ？ ---> 是 正 品 啊 ， 可 以 扫 码 的 <--- 防 晒 霜 / 乳 SPF 11 - 20 PA + + 玉 兰 油 OLAY 防 晒 霜 多 效 修 护 50 g （ SPF 15 滋 养 水 润 均 匀 肤 色 新 老 包 装 随 机 发 货 ） 暂 无 信 息 中 国 大 陆 美 妆 护 肤 面 部 护 肤 防 晒
进展 35.61359252114557 第 600000 行 我 在 店 面 上 买 的 是 900 克 的 ， 这 个 怎 么 才 800 ---> 奶 粉 还 不 错 ， 我 家 女 儿 没 有 任 何 不 良 反 应 <--- 1 段 200 - 299 元 0 - 6 个 月 瑞 士 进 口 801 - 1000 g 牛 奶 粉 新 西 兰 斐 婴 宝 （ ） 新 生 儿 奶 粉 新 西 兰 进 口 奶 粉 婴 幼 儿 奶 粉 1 段 奶 粉 800 克 新 西 兰 母 婴 奶 粉 婴 幼 奶 粉
进展 41.54919127466983 第 700000 行 吸 奶 时 声 音 大 吗 ---> 不 大 <--- 吸 奶 器 独 立 装 硅 胶 国 产 500 - 999 元 gb 好 孩 子 电 动 吸 奶 器 孕 产 妇 吸 力 大 静 音 挤 奶 器 自 动 母 乳 收 集 器 可 充 电 C 8117 母 婴 喂 养 用 品 吸 奶 器
进展 47.48479002819409 第 800000 行 你 们 买 的 ipone 玻 璃 后 壳 与 边 框 衔 接 处 有 缝 隙 嘛 ， 我 今 天 买 的 银 色 就 出 现 这 种 问 题 了 。 ---> 没 有 毛 病 啊 <--- 其 他 移 动 4 G / 联 通 4 G / 电 信 4 G 64 GB Apple iPhone 8 ( A 1863 ) 64 GB 深 空 灰 色 移 动 联 通 电 信 4 G 手 机 中 国 大 陆 手 机 手 机 通 讯 手 机
进展 53.42038878171836 第 900000 行 华 为 Mate 10 能 用 吗 ---> 华 为 系 列 都 能 用 <--- 线 控 自 拍 杆 自 拍 荣 耀 自 拍 杆 原 装 无 线 远 程 蓝 牙 三 脚 架 适 用 于 华 为 P 9 苹 果 6 魅 族 OPPO 小 米 VIVO 等 手 机 线 控 自 拍 神 器 中 国 大 陆 手 机 手 机 配 件 拍 照 配 件
进展 59.35598753524262 第 1000000 行 大 佬 们 ， 你 们 用 到 现 在 会 有 卡 顿 现 象 吗 ？ 想 买 个 手 机 用 上 三 年 ---> 暂 时 没 有 <--- 其 他 曲 面 屏 符 合 全 面 屏 比 例 粉 色 系 八 核 光 学 变 焦 移 动 4 G / 联 通 4 G / 电 信 4 G 防 蓝 光 安 卓 （ Android ） 3000 mAh - 3999 mAh 无 线 充 电 人 脸 识 别 5 . 6 英 寸 及 以 上 OLED 屏 薄 （ 7 mm - 8 . 5 mm ） 800 万 - 1599 万 1200 万 - 1999 万 人 工 智 能 双 卡 4 GB 64 GB 游 戏 模 式 VOLTE 功 能 三 星 Galaxy S 8 （ SM - G 9500 ） 4 GB + 64 GB 芭 比 粉 移 动 联 通 电 信 4 G 手 机 双 卡 双 待 中 国 大 陆 手 机 手 机 通 讯 手 机
进展 65.29158628876688 第 1100000 行 会 不 会 透 ？ ---> 不 会 ， 棉 质 ， 舒 服 <--- 常 规 袖 常 规 款 500 以 上 修 身 型 2017 夏 季 25 - 29 周 岁 黑 色 系 圆 领 165 其 它 棉 / 丝 光 棉 短 袖 纯 色 哈 吉 斯 HAZZYS 新 款 夏 装 T 恤 衫 女 士 时 尚 简 约 短 袖 T 恤 ASTSE 07 BE 17 服 饰 内 衣 女 装 T 恤
进展 71.22718504229114 第 1200000 行 显 卡 会 吱 吱 响 吗 ？ ---> 我 没 听 到 <--- 6 G 发 烧 级 GTX 1060 七 彩 虹 iGame 1700 - 2599 发 烧 七 彩 虹 ( ) iGame 1060 烈 焰 战 神 U - 6 GD 5 GTX 1060 显 卡 中 国 大 陆 电 脑 、 办 公 电 脑 配 件 显 卡
进展 77.1627837958154 第 1300000 行 我 身 高 1 . 58 ， 体 重 120 ， 适 合 穿 多 大 的 号 码 ---> XL <--- 可 外 穿 圆 领 衣 裤 两 件 套 女 士 套 装 纯 棉 纯 色 卡 通 薄 款 短 裤 M 粉 色 系 字 母 L XL 套 头 短 袖 休 闲 套 头 0 - 99 夏 季 奥 芬 蝶 纯 棉 睡 衣 女 夏 季 短 袖 五 七 分 中 短 裤 夏 天 款 家 居 服 女 士 青 年 清 纯 学 生 女 款 全 棉 圆 领 休 闲 运 动 套 装 新 款 可 外 穿 中 国 大 陆 服 饰 内 衣 内 衣 睡 衣 / 家 居 服
进展 83.09838254933966 第 1400000 行 我 一 米 七 ， 115 斤 穿 什 么 码 数 合 适 ---> S 码 <--- 水 洗 常 规 中 腰 灰 色 0 - 199 九 分 裤 时 尚 休 闲 其 它 2018 夏 季 简 约 其 他 日 常 上 班 微 弹 青 少 年 棉 修 身 裤 其 他 黑 色 夏 季 Dcw 束 脚 裤 男 九 分 休 闲 裤 男 修 身 小 脚 2018 春 夏 新 款 韩 版 社 会 小 伙 休 闲 裤 男 原 创 设 计 SD 中 国 大 陆 服 饰 内 衣 男 装 休 闲 裤
进展 89.03398130286392 第 1500000 行 请 问 煮 稀 饭 多 久 呢 ？ 谢 谢 ！ ！ ---> 你 直 接 调 到 煮 粥 的 上 面 就 行 了 ， <--- 5 - 8 人 手 动 按 键 排 气 5 L 电 脑 式 双 胆 底 盘 加 热 直 壁 内 胆 美 的 （ Midea ） 电 压 力 锅 PSS 5068 P 双 胆 5 L 一 键 排 气 电 高 压 锅 中 国 大 陆 家 用 电 器 厨 房 小 电 电 压 力 锅
进展 94.96958005638818 第 1600000 行 1 . 66 点 要 多 大 的 呢 ， 我 喜 欢 紧 身 的 ， 是 紧 身 的 吗 ---> 是 的 。 紧 身 的 <--- 上 班 其 它 　 日 常 青 春 流 行 四 季 方 领 其 它 青 少 年 青 春 休 闲 100 - 199 雨 天 休 闲 修 身 型 2018 春 季 短 袖 棉 涤 港 蒂 蒎 短 袖 衬 衫 男 2018 夏 季 新 款 韩 版 修 身 免 烫 商 务 休 闲 长 袖 衬 衫 男 装 衬 衣 服 服 饰 内 衣 男 装 衬 衫
data/train.txt总计 1684750 行，有效问答有1684750
平均问题长 26.773032794183113 平均回答长 21.52076866003858 平均详情长 171.29869832319335
209.50360012054443 秒处理 1684750 条
 已写入 /home/cs/qa_chat_jd3.1/data/train_src.txt
 已写入 /home/cs/qa_chat_jd3.1/data/train_tgt.txt
 已写入 /home/cs/qa_chat_jd3.1/data/train_attr.txt
read正在读取 /home/cs/qa_chat_jd3.1/data/valid.txt
0.001988649368286133 秒读出 800 条
进展 0.0 第 0 行 能 灭 鼠 吗 ？ ---> 灭 不 了 ， 是 不 进 家 <--- 室 内 老 鼠 无 香 国 产 家 用 单 包 装 其 它 驱 鼠 器 家 用 超 声 波 大 功 率 电 子 猫 灭 鼠 器 捕 鼠 器 老 鼠 干 扰 神 器 驱 老 鼠 不 用 药 驱 虫 器 蝙 蝠 驱 赶 器 防 鼠 器 驱 蟑 螂 跳 蚤 中 国 大 陆 家 庭 清 洁 / 纸 品 驱 蚊 驱 虫 灭 鼠 / 杀 虫 剂
data/valid.txt总计 800 行，有效问答有800
平均问题长 27.2675 平均回答长 20.69875 平均详情长 171.23875
0.09871196746826172 秒处理 800 条
 已写入 /home/cs/qa_chat_jd3.1/data/valid_src.txt
 已写入 /home/cs/qa_chat_jd3.1/data/valid_tgt.txt
 已写入 /home/cs/qa_chat_jd3.1/data/valid_attr.txt
read正在读取 /home/cs/qa_chat_jd3.1/data/test.txt
0.0005908012390136719 秒读出 200 条
进展 0.0 第 0 行 防 摔 吗 ， ， ， ---> 一 般 ～ <--- 1 . 7 L 高 硼 硅 玻 璃 防 干 烧 自 动 断 电 电 热 水 壶 家 庭 壶 体 标 示 办 公 室 小 熊 （ Bear ） 电 热 水 壶 304 不 锈 钢 家 用 高 硼 硅 玻 璃 自 动 断 电 烧 水 壶 ZDH - A 17 G 5 1 . 7 L 电 水 壶 佛 山 顺 德 家 用 电 器 厨 房 小 电 电 水 壶 / 热 水 瓶
data/test.txt总计 200 行，有效问答有200
平均问题长 27.245 平均回答长 19.27 平均详情长 174.855
0.025002717971801758 秒处理 200 条
 已写入 /home/cs/qa_chat_jd3.1/data/test_src.txt
 已写入 /home/cs/qa_chat_jd3.1/data/test_tgt.txt
 已写入 /home/cs/qa_chat_jd3.1/data/test_attr.txt

'''
