import argparse
import torch
import os
from time import time
import random
from Util import *


def char_type(c):  # 判断字符类型
    # https://gist.github.com/shingchi/64c04e0dd2cbbfbc1350
    if ord(c) <= 0x007f:  # ascii
        if ord(c) >= 0x0030 and ord(c) <= 0x0039:
            return "number"
        if ord(c) >= 0x0041 and ord(c) <= 0x005a:
            return "latin"
        if ord(c) >= 0x0061 and ord(c) <= 0x007a:
            return "latin"
        return "ascii_symble"
    if ord(c) >= 0x4E00 and ord(c) <= 0x9fff:
        return "han"  # 标准CJK文字
    if ord(c) >= 0xFF00 and ord(c) <= 0xFFEF:
        return "han_symble"  # 全角ASCII、全角中英文标点、半宽片假名、半宽平假名、半宽韩文字母：FF00-FFEF
    if ord(c) >= 0x3000 and ord(c) <= 0x303F:
        return "han_symble"  # CJK标点符号：3000-303F
    return "other"


def split_lans(line):
    last_latin = None
    grams = []
    for gram in line:  # 还是字符串形式
        if char_type(gram) == "latin":
            if last_latin == None or last_latin == False:
                grams.append(gram)
            else:
                grams[-1] += gram
            last_latin = True
        else:
            grams.append(gram)
            last_latin = False
    return grams


def merge_gram(line):
    last_type = None
    tokens = []
    for gram in line:
        if char_type(gram) == "latin":
            if last_type == "latin":
                tokens[-1] += gram
            else:
                tokens.append(gram)
        elif char_type(gram) == "number":
            if last_type == "number":
                tokens[-1] += gram
            else:
                tokens.append(gram)
        else:
            if gram not in [None, '', ' ']:
                tokens.append(gram)
        last_type = char_type(gram)
    return tokens


def tokenize(line):
    # return list(line)
    # return line.split(" ")
    # words = line.split()
    # line = ''.join(line.split(" "))
    # words = split_lans(line)
    words = merge_gram(line)
    # line = ' '.join(words)
    # words = line.split(" ")
    re = []
    for word in words:
        if len(word) > 7:
            continue
        if word:
            re.append(word)
    return re


def tb_pair(row):
    words = row.split("\t")
    # 数据多，出错丢弃.如果数据出错，前面几段都归为问题，最后一个归为回答.
    if len(words) < 3 or int(words[0]) != 1:
        return None, None
    question = words[1].strip()
    answer = words[2].strip()

    question = " ".join(tokenize(question))
    answer = " ".join(tokenize(answer))

    if len(question) < 2 or len(answer) < 2:
        print("tb_pair字太少", row)
        return None, None
    return question, answer


def get_jdpair(row):
    '''
        full_doc = ["skuid \t attributes \t review  \t counter \t question \t answer"]
    '''
    sents = row.split("\t")
    if len(sents) != 6:
        return None, None, None
    # question = pure(sents[0].strip())
    # answer = pure(sents[1].strip())
    question = sents[4].strip()
    answer = sents[5].strip()
    attr = sents[1].strip()

    question = " ".join(tokenize(question))
    answer = " ".join(tokenize(answer))
    attr = " ".join(tokenize(attr))

    # if len(question) < 1 or len(answer) < 1:
    #     print("get_pair字太少", row)
    #     return None, None
    return question, answer, attr


def get_pair(row):
    sents = row.split("\t")
    if len(sents) < 2:
        return None, None
    # question = pure(sents[0].strip())
    # answer = pure(sents[1].strip())
    question = sents[0].strip()
    answer = sents[1].strip()

    question = " ".join(tokenize(question))
    answer = " ".join(tokenize(answer))

    # if len(question) < 1 or len(answer) < 1:
    #     print("get_pair字太少", row)
    #     return None, None
    return question, answer


def read(path, begin=0, end=-1):
    t0 = time()
    print("read正在读取", os.path.abspath(path))
    doc = open(path, "r", encoding="utf-8").read().splitlines()
    random.shuffle(doc)
    if end < 0:
        end = len(doc)
    print(time() - t0, "秒读出", len(doc), "条")
    t0 = time()
    qlenth, alenth, tlenth = 0, 0, 0  # 问题长度
    questions, answers, attrs = [], [], []
    for i in range(len(doc)):
        if i < begin:
            continue
        if i > end:
            break
        row = doc[i]
        # question, answer = tb_pair(row)
        # question, answer = get_pair(row)
        question, answer, attr = get_jdpair(row)
        if question == None or answer == None or attr == None:
            continue

        qlenth += len(question)
        alenth += len(answer)
        tlenth += len(attr)
        questions.append(question)
        answers.append(answer)
        attrs.append(attr)

        if i % 100000 == 0:
            print("进展", i * 100.0 / (end - begin), "第", i, "行", question, "--->", answer, "<---", attr)

    assert len(answers) == len(questions)
    print(str(path) + "总计", len(doc), "行，有效问答有" + str(len(answers)))
    print("平均问题长", qlenth / len(questions), "平均回答长", alenth / len(answers), "平均详情长", tlenth / len(attrs))
    print(time() - t0, "秒处理", len(answers), "条")
    return questions, answers, attrs


def split_test(path):
    t0 = time()
    print("read正在读取", os.path.abspath(path))
    doc = open(path, "r", encoding="utf-8").read().splitlines()
    random.shuffle(doc)
    print(time() - t0, "秒读出", len(doc), "条")
    splits_write(doc, dir="data", suffix=".txt")


def main():
    # dir = "../data/tb"
    # source = "/train.txt"

    # dir = "../data/qa_data"
    # source = "qa_data.txt"

    # dir = "../data/chitchat_data"
    # source = "chitchat_data.txt"

    # dir = "../data/all"
    # source = "balance.txt"

    dir = "../data/jd"
    source = "full.skuqa"

    # split_test(dir + "/" + source)
    names = ["train", "valid", "test"]
    marks = ["src", "tgt", "attr"]
    for name in names:
        result = read("data/" + name + ".txt", begin=0, end=-1)
        for i in range(3):
            path = "data/" + name + "_" + marks[i] + ".txt"
            with open(path, "w", encoding="utf-8") as f:
                f.write("\n".join(result[i]))
            print(" 已写入", os.path.abspath(path))

    # questions, answers, attrs = read(dir + "/" + source, begin=0, end=-1)
    # splits_write(questions, dir="data", suffix="_src.txt")
    # splits_write(answers, dir="data", suffix="_tgt.txt")
    # splits_write(attrs, dir="data", suffix="_attr.txt")


if __name__ == '__main__':
    t0 = time()
    main()
    print(time() - t0, "秒执行完main()")

'''
../data/jd//full.skuqa总计 1685750 行，有效问答有300001
平均问题长 27.155192816023945 平均回答长 21.655607814640618 平均详情长 176.3915820280599
27.85947823524475 秒处理 300001 条

Python 3.7.3 (default, Mar 27 2019, 17:13:21) [MSC v.1915 64 bit (AMD64)] on win32
runfile('D:/code/qa_chat_jd3/gen_data.py', wdir='D:/code/qa_chat_jd3')
read正在读取 D:\code\qa_chat_jd3\data\train.txt
7.964700222015381 秒读出 1684750 条
进展 0.0 第 0 行 这 可 以 打 电 话 吗 ， 可 以 插 卡 吗 ， 可 以 像 手 机 那 样 有 手 机 号 码 吗 ， 可 以 有 流 量 吗 ---> 买 4 g 版 本 就 可 以 <--- 保 护 套 华 为 （ HUAWEI ） 荣 耀 畅 玩 平 板 2 8 英 寸 棕 色 皮 套 中 国 大 陆 电 脑 、 办 公 电 脑 整 机 平 板 电 脑 配 件
进展 5.935598753524261 第 100000 行 这 么 便 宜 ， 当 夜 用 卫 生 巾 行 么 ---> 老 人 家 小 便 失 禁 日 夜 用 <--- 71 - 109 CM 中 国 大 陆 透 气 吸 水 1 - 49 片 纸 尿 片 通 用 其 它 普 通 装 国 产 魔 妮 （ MoNi ） 成 人 纸 尿 片 老 人 产 妇 尿 片 24 片 【 640 * 280 mm 】 中 国 大 陆 母 婴 尿 裤 湿 巾 成 人 尿 裤
进展 11.871197507048523 第 200000 行 这 么 贵 还 是 盛 大 入 驻 ？ 240 有 人 会 买 ？ 碧 欧 泉 傻 了 还 是 京 东 傻 了 ？ ---> 感 觉 上 当 了 <--- 任 何 肤 质 洁 面 霜 / 膏 清 洁 毛 孔 补 水 深 层 清 洁 进 口 其 它 欧 美 保 湿 碧 欧 泉 （ ） 男 士 新 水 动 力 洁 面 膏 125 ml （ 水 感 清 洁 洁 面 清 爽 男 士 护 肤 洗 面 奶 原 装 进 口 ） 中 国 大 陆 美 妆 护 肤 男 士 面 部 护 肤 男 士 洁 面
进展 17.806796260572785 第 300000 行 请 问 这 个 是 什 么 味 道 的 ？ ---> 淡 香 的 <--- 防 晒 霜 / 乳 SPF 50 持 久 度 进 口 PA + + + 日 本 31 - 50 mL / g 隔 离 任 何 肤 质 通 用 保 湿 【 日 本 进 口 】 碧 柔 （ Biore ） 轻 透 倍 护 防 晒 乳 SPF 50 + PA + + + 40 ml 轻 透 不 厚 重 流 汗 也 清 爽 日 本 美 妆 护 肤 面 部 护 肤 防 晒
进展 23.742395014097045 第 400000 行 内 存 是 哪 个 品 牌 的 ？ ---> 我 的 是 三 星 的 DDR 4 <--- 惠 普 （ HP ） 银 河 舰 队 电 竞 版 光 影 暗 影 精 灵 笔 记 本 电 脑 畅 游 人 电 竞 版 i 5 游 戏 本 手 提 电 脑 15 . 6 英 寸 电 脑 、 办 公 电 脑 整 机 游 戏 本
进展 29.67799376762131 第 500000 行 支 持 麦 克 风 吗 ？ ？ 游 戏 耳 机 连 到 电 脑 ， 带 麦 克 风 的 ---> 不 支 持 麦 克 风 ！ <--- 车 载 连 接 2 米 工 程 类 音 箱 线 音 频 线 3 . 5 mm 音 频 线 音 响 线 飞 利 浦 （ PHILIPS ） SWA 5511 / 93 C 镀 银 AUX 车 用 高 保 真 3 . 5 mm 音 频 线 2 米 公 对 公 手 机 电 脑 音 箱 连 接 线 中 国 大 陆 电 脑 、 办 公 外 设 产 品 线 缆
进展 35.61359252114557 第 600000 行 请 问 你 们 买 之 前 ， 看 过 那 个 检 测 报 告 吗 ， 空 白 样 跟 陶 瓷 滤 芯 分 别 代 表 啥 意 思 啊 ， 这 个 是 正 品 吗 ？ 好 用 吗 ---> 检 测 报 告 我 不 是 太 清 楚 ， 不 过 我 可 以 给 你 说 说 用 后 的 感 受 。 我 用 了 一 个 多 月 了 ， 感 觉 是 有 点 用 处 ， 但 是 效 果 没 有 想 象 的 好 ， 如 果 你 家 水 质 很 差 的 话 建 议 买 个 更 好 点 的 ， 另 外 这 款 产 品 水 龙 头 固 定 处 竟 然 会 生 锈 ， 还 有 滤 水 器 外 壳 也 有 点 生 锈 ， 很 尴 尬 ！ <--- 其 他 小 体 积 全 屋 净 水 超 滤 机 1800 - 2799 道 尔 顿 （ Doulton ） 净 水 器 家 用 直 饮 D - IS 厨 房 自 来 水 过 滤 器 不 用 电 无 废 水 无 桶 净 水 机 赠 原 装 滤 芯 家 用 电 器 生 活 电 器 净 水 器
进展 41.54919127466983 第 700000 行 眼 镜 腿 上 面 带 V 吗 ---> 不 带 <--- 休 闲 防 UVA 通 用 韩 范 儿 简 约 百 搭 其 他 椭 圆 形 脸 2018 年 春 季 圆 脸 方 脸 长 脸 炫 彩 其 他 潮 流 个 性 小 清 新 商 务 中 性 梦 幻 公 主 彩 膜 太 阳 镜 其 他 运 动 复 古 太 阳 镜 经 典 树 脂 通 用 / 情 侣 原 创 设 计 运 动 太 阳 镜 彩 色 透 明 名 媛 淑 女 街 拍 0 - 99 蓝 眸 2018 新 款 太 阳 镜 女 个 性 网 红 明 星 同 款 墨 镜 潮 韩 版 复 古 大 框 显 瘦 圆 脸 素 颜 眼 镜 装 饰 眼 睛 男 中 国 大 陆 服 饰 内 衣 服 饰 配 件 太 阳 镜
进展 47.48479002819409 第 800000 行 这 腊 肉 是 风 干 不 是 熏 干 的 吗 ？ ---> 不 是 熏 的 ， 是 咸 肉 ， 用 盐 腌 的 ， 超 级 赞 <--- 加 热 华 东 腊 肉 袋 装 猪 肉 原 味 挑 货 佬 家 乡 咸 肉 腌 肉 安 徽 风 干 老 后 腿 腊 肉 干 农 家 自 制 腌 制 土 猪 正 宗 特 产 500 g 食 品 饮 料 休 闲 食 品 熟 食 腊 味
进展 53.42038878171836 第 900000 行 买 了 的 亲 够 25000 毫 安 吗 ---> 耐 用 一 般 吧 <--- 支 持 多 U 口 输 出 锂 聚 合 物 电 池 25000 mAh 及 以 上 塑 料 罗 马 仕 （ ROMOSS ） sense 9 25000 毫 安 充 电 宝 大 容 量 移 动 电 源 3 USB 输 出 聚 合 物 苹 果 / 安 卓 手 机 / 平 板 通 用 白 色 暂 无 信 息 中 国 大 陆 手 机 手 机 配 件 移 动 电 源
进展 59.35598753524262 第 1000000 行 这 款 可 以 带 妆 的 情 况 喷 吗 ？ ---> 可 以 <--- 进 口 舒 缓 镇 静 补 水 保 湿 任 何 肤 质 喷 雾 欧 美 薇 姿 （ VICHY ） 矿 物 赋 能 温 泉 水 喷 雾 300 ml （ 大 喷 保 湿 补 水 舒 缓 喷 雾 爽 肤 水 喷 雾 法 国 原 装 进 口 ） 法 国 美 妆 护 肤 面 部 护 肤 爽 肤 水 / 化 妆 水
进展 65.29158628876688 第 1100000 行 你 好 ， 请 问 身 高 1 . 75 体 重 150 要 多 大 号 的 ？ ---> xl <--- 圆 领 印 花 其 它 青 年 0 - 99 2017 春 季 简 约 休 闲 短 袖 T 恤 标 准 型 棉 M 灰 色 夏 季 青 春 休 闲 短 袖 青 春 流 行 【 120 元 2 件 】 Baleno / 班 尼 路 时 尚 简 约 雄 鹰 徽 章 印 花 男 士 t 恤 夏 季 半 袖 男 短 袖 男 服 饰 内 衣 男 装 T 恤
进展 71.22718504229114 第 1200000 行 请 问 ， 你 们 家 的 是 龙 利 鱼 还 是 巴 沙 鱼 ？ ---> 其 实 好 像 都 是 一 个 东 西 ， 只 是 名 字 不 一 样 ， 都 没 刺 <--- 其 它 进 口 AJ 越 南 进 口 龙 利 鱼 柳 深 海 新 鲜 冷 冻 去 皮 去 刺 无 骨 龙 利 鱼 柳 单 片 约 400 g 生 鲜 海 鲜 水 产 鱼 类
进展 77.1627837958154 第 1300000 行 驱 蚊 功 能 可 以 关 掉 不 用 吗 ？ ---> 可 以 <--- 三 档 调 节 单 冷 2 - 8 小 时 5 - 7 L 正 常 风 、 自 然 风 、 睡 眠 风 竖 出 风 遥 控 式 志 高 （ chigo ) FSE - 12 遥 控 驱 蚊 款 冷 风 扇 / 空 调 扇 / 电 风 扇 （ 金 黑 色 ） 浙 江 家 用 电 器 生 活 电 器 冷 风 扇
进展 83.09838254933966 第 1400000 行 和 实 体 店 的 货 源 有 差 吗 ？ 实 体 店 店 员 说 最 好 的 都 在 实 体 店 里 ---> 没 有 <--- 无 线 流 行 、 摇 滚 、 电 音 头 戴 式 Bose 35 无 线 耳 机 II - - 银 色 中 国 数 码 影 音 娱 乐 耳 机 / 耳 麦
进展 89.03398130286392 第 1500000 行 能 装 钓 箱 上 吗 ？ ---> 能 装 <--- 锂 电 池 钓 鱼 灯 电 池 垂 钓 LED 神 火 （ supfire ） D 11 手 电 筒 手 提 式 夜 钓 灯 黄 蓝 白 三 光 源 钓 鱼 灯 防 水 变 焦 垂 钓 LED 灯 中 国 大 陆 广 东 深 圳 市 运 动 户 外 户 外 装 备 户 外 照 明
进展 94.96958005638818 第 1600000 行 信 号 好 不 好 ？ ---> 看 当 地 网 络 覆 盖 情 况 ！ <--- 支 持 内 存 卡 普 通 （ 8 . 5 mm 以 上 ） 橙 色 系 无 其 他 键 盘 3 . 0 英 寸 及 以 下 500 万 以 下 2 G 网 络 双 卡 4000 mAh - 5999 mAh 其 他 2 GB 以 下 小 辣 椒 G 108 移 动 / 联 通 / 2 G 电 霸 三 防 老 人 手 机 双 卡 双 待 橙 色 中 国 大 陆 手 机 手 机 通 讯 手 机
data/train.txt总计 1684750 行，有效问答有1684750
平均问题长 26.77361448286096 平均回答长 21.520267101943908 平均详情长 171.29754978483456
285.12993574142456 秒处理 1684750 条
 已写入 D:\code\qa_chat_jd3\data2\train_src.txt
 已写入 D:\code\qa_chat_jd3\data2\train_tgt.txt
 已写入 D:\code\qa_chat_jd3\data2\train_attr.txt
read正在读取 D:\code\qa_chat_jd3\data\valid.txt
0.0040225982666015625 秒读出 800 条
进展 0.0 第 0 行 电 饭 煲 放 在 上 面 会 不 会 太 高 ？ ---> 挺 合 适 的 不 高 ！ <--- 收 纳 架 1 层 400 系 列 不 锈 钢 宝 优 妮 厨 房 微 波 炉 架 子 置 物 架 厨 具 收 纳 架 烤 箱 架 不 锈 钢 落 地 储 物 架 DQ 1210 - C 暂 无 信 息 中 国 上 海 厨 具 厨 房 配 件 厨 房 置 物 架
data/valid.txt总计 800 行，有效问答有800
平均问题长 25.715 平均回答长 20.86375 平均详情长 175.8175
0.1376333236694336 秒处理 800 条
 已写入 D:\code\qa_chat_jd3\data2\valid_src.txt
 已写入 D:\code\qa_chat_jd3\data2\valid_tgt.txt
 已写入 D:\code\qa_chat_jd3\data2\valid_attr.txt
read正在读取 D:\code\qa_chat_jd3\data\test.txt
0.0009963512420654297 秒读出 200 条
进展 0.0 第 0 行 不 懂 穿 多 大 码 ---> 平 常 码 <--- 皮 轻 质 镂 空 休 闲 拼 色 胶 粘 鞋 夹 趾 橡 胶 人 造 皮 革 2018 年 300 - 399 41 平 底 搭 扣 休 闲 透 气 鞋 黑 色 沙 滩 鞋 佐 佐 卡 凉 鞋 男 夏 季 新 品 超 火 男 士 软 底 透 气 户 外 防 滑 耐 磨 沙 滩 鞋 英 伦 特 大 码 凉 拖 鞋 男 两 用 人 字 拖 鞋 男 47 鞋 靴 流 行 男 鞋 凉 鞋 / 沙 滩 鞋
data/test.txt总计 200 行，有效问答有200
平均问题长 28.555 平均回答长 22.835 平均详情长 166.215
0.03390669822692871 秒处理 200 条
 已写入 D:\code\qa_chat_jd3\data2\test_src.txt
 已写入 D:\code\qa_chat_jd3\data2\test_tgt.txt
 已写入 D:\code\qa_chat_jd3\data2\test_attr.txt

'''
