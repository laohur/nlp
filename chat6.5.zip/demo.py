#614778493287	请问这个复读机中的文件可以通过文件夹分类整理吗，还是所有的mp3都在一个文件夹中，找文件是要逐个翻？	可以分类
# 191899547	配上	锐龙	AMD	Ryzen	5	1400	，不买显卡，能用吗？	要配独显才能用哦
# 199410817	请问你们的蓝牙能充满电能听多少个小时啊~~我开60音量不间断大概能听6个小时左右还有一半的电！想问问大家的是怎样？国外购买，国外保修一年255美刀	2小时
"""将UTF-8编码转换为Unicode编码"""
#def toUnicode(string):
    #ustring = string
    #if not isinstance(string, unicode):
        #ustring = string.decode('UTF-8')
    #return ustring


line = "#614778493287	请问这个复读机48%中的文件可fdghfghgd以通过文件夹分类整理吗，还是所有的mp3都在一个文件夹中，找文件是要逐个翻？	可以分类"
line2="1201736330543	会起球吗	材料是多少的棉	48%棉的，起不起球还不知道，还没穿"
#ustr = toUnicode(line)


def split_chinese(line):
    # print("之前",line)
    words=[]
    for word in line:
        print(word, ord(word))
        if ord(word) >=0x4E00 and ord(word)<=0x9fff:
            word=" "+word+" "
        words.append(word)
    line="".join(words)
    while "  " in line:
        line= line.replace("  "," " )
    # print("之后",line2)
    return line

print(split_chinese(line2))