"处理文本"
import argparse
import torch
import transformer.Constants as Constants
from time import time
import os
import math


class Reader():
    def __init__(self):
        self.word2idx = {
            Constants.BOS_WORD: Constants.BOS,
            Constants.EOS_WORD: Constants.EOS,
            Constants.PAD_WORD: Constants.PAD,
            Constants.UNK_WORD: Constants.UNK}

    def tokenize(self, line):
        return line.splits()

    def load_file(self, path, max_sent_len, begin=0, end=math.inf, keep_case=False):
        if "vocab" in path:
            print("vocab", path)
        ''' 由文本生成词典和序列 '''
        word_insts = []
        trimmed_sent_count = 0
        t0 = time()
        print("正在读取", os.path.abspath(path), begin, "->", end)
        doc = open(path, "r", encoding="utf-8").read().splitlines()
        for i in range(len(doc)):
            if i < begin:
                continue
            if i > end:
                break
            sent = doc[i]
            if not keep_case:
                sent = sent.lower()
            # words = sent.split()
            words = self.tokenize(sent)
            if len(words) > max_sent_len:
                # if len(words)>max_sent_len*9:
                # print("过长被截断",len(words),words)
                trimmed_sent_count += 1
            # 左截断，左右各一半更好
            word_inst = words[:max_sent_len]
            line = [[Constants.BOS_WORD] + word_inst + [Constants.EOS_WORD]] if word_inst else [None]
            word_insts += line

        print('[Info] ""文件{}中获取{}句子'.format(path, len(word_insts)))

        if trimmed_sent_count > 0:
            print('[Warning] {}个句子被截断至最大长度{}.'.format(trimmed_sent_count, max_sent_len))

        return word_insts

    def build_vocab_idx(self, doc, min_word_count):
        ''' Trim vocab by number of occurence '''

        full_vocab = set(w for sent in doc for w in sent)  # 先大后小
        print('[Info] 原始词库 =', len(full_vocab))

        word_count = {w: 0 for w in full_vocab}

        for sent in doc:
            for word in sent:
                word_count[word] += 1

        ignored_word_count = 0
        for word, count in word_count.items():
            if word not in self.word2idx:
                if count >= min_word_count:
                    self.word2idx[word] = len(self.word2idx)
                else:
                    ignored_word_count += 1

        print('[Info] 频繁字典大小 = {},'.format(len(self.word2idx)), '最低频数 = {}'.format(min_word_count))
        print("[Info] 忽略罕词数 = {}".format(ignored_word_count))
        return self.word2idx

    def convert_w2id_seq(self, word_insts):
        ''' Mapping words to idx sequence. '''
        return [[self.word2idx.get(w, Constants.UNK) for w in s] for s in self.word_insts]


def main(required=None):
    dir = "../data/tb"
    parser = argparse.ArgumentParser()
    parser.add_argument('-train_src', default=dir + "/train_src.txt")
    parser.add_argument('-train_tgt', default=dir + "/train_tgt.txt")
    parser.add_argument('-valid_src', default=dir + "/valid_src.txt")
    parser.add_argument('-valid_tgt', default=dir + "/valid_tgt.txt")
    parser.add_argument('-save_data', default="data/train.json")
    parser.add_argument('-max_len', '--max_word_seq_len', type=int, default=20)
    parser.add_argument('-min_word_count', type=int, default=5)
    parser.add_argument('-keep_case', action='store_true', default=False)
    parser.add_argument('-share_vocab', action='store_true', default=True)
    parser.add_argument('-vocab', default=None)

    args = parser.parse_args()
    args.max_token_seq_len = args.max_word_seq_len + 2  # include the <s> and </s>

    # Training set
    train_src_word_insts = load_file(args.train_src, args.max_word_seq_len, begin=0, end=10000,
                                     keep_case=args.keep_case)
    train_tgt_word_insts = load_file(args.train_tgt, args.max_word_seq_len, begin=0, end=10000,
                                     keep_case=args.keep_case)

    if len(train_src_word_insts) != len(train_tgt_word_insts):
        print('[Warning] 训练集源标句子数量不等,将被截断' + args.train_src, len(train_src_word_insts), args.train_tgt,
              len(train_tgt_word_insts))
        min_inst_count = min(len(train_src_word_insts), len(train_tgt_word_insts))
        train_src_word_insts = train_src_word_insts[:min_inst_count]
        train_tgt_word_insts = train_tgt_word_insts[:min_inst_count]

    # Remove empty instances
    train_src_word_insts, train_tgt_word_insts = list(zip(*[
        (s, t) for s, t in zip(train_src_word_insts, train_tgt_word_insts) if s and t]))

    # Validation set
    valid_src_word_insts = load_file(args.valid_src, args.max_word_seq_len, args.keep_case)
    valid_tgt_word_insts = load_file(args.valid_tgt, args.max_word_seq_len, args.keep_case)

    if len(valid_src_word_insts) != len(valid_tgt_word_insts):
        print('[Warning] 源标句子数量不等,将被截断')
        print(args.valid_src, len(valid_src_word_insts), args.valid_tgt, len(valid_tgt_word_insts))
        min_inst_count = min(len(valid_src_word_insts), len(valid_tgt_word_insts))
        valid_src_word_insts = valid_src_word_insts[:min_inst_count]
        valid_tgt_word_insts = valid_tgt_word_insts[:min_inst_count]

    # Remove empty instances
    valid_src_word_insts, valid_tgt_word_insts = list(zip(*[
        (s, t) for s, t in zip(valid_src_word_insts, valid_tgt_word_insts) if s and t]))

    # Build vocabulary
    if args.vocab:
        predefined_data = torch.load(args.vocab)
        assert 'dict' in predefined_data

        print('[Info] 加载词典')
        src_word2idx = predefined_data['dict']['src']
        tgt_word2idx = predefined_data['dict']['tgt']
    else:
        if args.share_vocab:
            print('[Info] 从源标文本构建词典')
            word2idx = build_vocab_idx(
                train_src_word_insts + train_tgt_word_insts, args.min_word_count)
            src_word2idx = tgt_word2idx = word2idx
            print("word2idx", word2idx)
        else:
            print('[Info] 从源文本构建词典')
            src_word2idx = build_vocab_idx(train_src_word_insts, args.min_word_count)
            print('[Info] 从文本构建词典')
            tgt_word2idx = build_vocab_idx(train_tgt_word_insts, args.min_word_count)

    # word to index
    print('[Info] 源文本字典序列化')
    train_src_insts = convert_w2id_seq(train_src_word_insts, src_word2idx)
    valid_src_insts = convert_w2id_seq(valid_src_word_insts, src_word2idx)
    print("训练集源  train_src_insts", len(train_src_insts), "验证集源 valid_src_insts", len(valid_src_insts))

    print('[Info] 标文本字典序列化')
    train_tgt_insts = convert_w2id_seq(train_tgt_word_insts, tgt_word2idx)
    valid_tgt_insts = convert_w2id_seq(valid_tgt_word_insts, tgt_word2idx)
    print("训练集标  train_tgt_insts", len(train_tgt_insts), "验证集标 valid_tgt_insts", len(valid_tgt_insts))
    # for line in valid_tgt_insts:
    #     print(len(line),line)
    # 10[2, 1989, 159, 1858, 2587, 1, 2457, 2868, 2101, 3]
    # 17[2, 1989, 2667, 2402, 1169, 667, 1371, 1304, 1993, 285, 2879, 1131, 1, 1, 2404, 2101, 3]

    data = {
        'settings': args,
        'dict': {
            'src': src_word2idx,
            'tgt': tgt_word2idx},
        'train': {
            'src': train_src_insts,
            'tgt': train_tgt_insts},
        'valid': {
            'src': valid_src_insts,
            'tgt': valid_tgt_insts}}

    print('[Info] 保存训练数据到 pickle file', args.save_data)
    torch.save(data, args.save_data)
    print('[Info] Finished.')


if __name__ == '__main__':
    main()
