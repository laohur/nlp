import argparse
import torch
import os
from time import time
import math
import random
import os


def split_chinese(line):
    # print("之前",line)
    # if "%" in line:
    #     print(line)
    words = []
    for word in line:
        if ord(word) >= 0x4E00 and ord(word) <= 0x9fff:
            word = " " + word + " "
        words.append(word)
    line2 = "".join(words)
    line2 = " ".join(line2.split())
    # print("之后",line2)
    return line2


def pure(line):
    line = line.strip('\n')
    line = line.strip('\r')
    return line.strip()


def read(path, begin=0, end=math.inf, ):
    t0 = time()
    print("read正在读取", os.path.abspath(path), begin, "->", end)
    doc = open(path, "r", encoding="utf-8").read().splitlines()
    print(time() - t0, "秒读出", len(doc), "条")
    # random.shuffle(doc)
    # line_count = 0  #总行数
    qlenth, alenth = 0, 0  # 问题长度
    questions, answers = [], []

    for i in range(len(doc)):
        if i < begin:
            continue
        if i > end:
            break

        row = doc[i]

        sents = row.split("\t")
        # 数据多，出错丢弃.如果数据出错，前面几段都归为问题，最后一个归为回答.
        if len(sents) < 3 or int(sents[0]) != 1:
            continue
        question = pure(sents[1])
        answer = pure(sents[2])

        qlenth += len(question)
        alenth += len(answer)
        questions.append(question)
        answers.append(answer)
        if i % 100000 == 0:
            print("正在处理", i, "行", question, answer)

    assert len(answers) == len(questions)
    print("行，有效问答有" + str(len(answers)))
    print("平均问题长", qlenth / len(answers), "平均回答长", alenth / len(answers))
    return questions, answers


def splits_write(x, suffix, dir, shuffle=True):
    print("splits_write正在划分训练集", os.path.abspath(dir))
    if shuffle:
        random.shuffle(x)
    test_len, valid_len = 100, 1000
    right = len(x) - test_len
    left = right - valid_len

    with open(dir + "/test" + suffix, "w", encoding="utf-8") as f:
        f.write("\n".join(x[:test_len]))
    print("测试集已写入")
    with open(dir + "/valid" + suffix, "w", encoding="utf-8") as f:
        f.write("\n".join(x[test_len:valid_len]))
    print("验证集已写入")
    with open(dir + "/train" + suffix, "w", encoding="utf-8") as f:
        f.write("\n".join(x[valid_len:]))
    print("训练集、验证集、测试集已写入", dir, "目录下")


def split(data, train_rate=0.8):
    train_len = int(len(data) * train_rate)
    valid_len = int((len(data) - train_len) / 2)
    return data[:train_len], data[train_len:train_len + valid_len], data[train_len + valid_len:]


def write(data, path):
    print(data[0:5])
    with open(path, 'w', encoding="utf8") as f:
        for line in data:
            line = pure(line)
            f.write(line + "\n")
        print("被写入" + os.path.abspath(path))
        f.close()


def main():
    dir = "../../data/tb"
    source = "train.txt"

    questions, answers = read(dir + "/" + source)
    splits_write(questions, dir=dir, suffix="_src.txt")
    splits_write(answers, dir=dir, suffix="_tgt.txt")



if __name__ == '__main__':
    main()
