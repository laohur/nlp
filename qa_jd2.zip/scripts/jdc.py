from time import time
import os
import random
import json


def sku_count(path):
    '''
614778493287	请问这个复读机中的文件可以通过文件夹分类整理吗，还是所有的mp3都在一个文件夹中，找文件是要逐个翻？	可以分类
191899547	配上	锐龙	AMD	Ryzen	5	1400	，不买显卡，能用吗？	要配独显才能用哦
'''
    t0 = time()
    print("read正在读取", os.path.abspath(path))
    doc = open(path, "r", encoding="utf-8").read().splitlines()
    # random.shuffle(doc)
    print(time() - t0, "秒读出", len(doc), "条")
    t0 = time()

    sku_counter = {}
    for line in doc:
        sents = line.split("\t")
        if sents[0] not in sku_counter:
            sku_counter[sents[0]] = 1
        else:
            sku_counter[sents[0]] += 1
    sku_counter = dict(sorted(sku_counter.items(), key=lambda kv: kv[1], reverse=True))
    with open("../data/jd_counter.json", "w", encoding="utf-8") as f:  # 特殊字符有问题，仅供人类阅读
        json.dump(sku_counter, f, ensure_ascii=False)
    # print(sku_counter)
    return sku_counter


def attrs(attrs):
    line = ""
    for kv_pair in attrs:
        if kv_pair[1]:
            line += kv_pair[1] + " "
    return line


def review1(path, review1_path):
    '''
    {
	"skuid": "6314359",
	"reviews": ["外观小巧，方正品？"],
	"attributes": [
		["材质", "其它"],
		["风格", "简约现代"],
		["分类", "指甲刀"],
		["name", "777指甲刀套装 指甲剪钳修容组合4件套DS-301（进口）"],
		["item_desc", "暂无信息"],
		["origin", "韩国"],
		["first_cate", "礼品箱包"],
		["second_cate", "礼品"],
		["third_cate", "美妆礼品"]
	]
}
    '''
    t0 = time()
    print("review1正在读取", os.path.abspath(path))
    # doc = open(path, "r", encoding="utf-8").read().splitlines()

    doc = []
    f = open(path, "r", encoding="utf-8")
    line = f.readline()
    item_count = 0
    while (line):
        item_count += 1
        item = json.loads(line)
        review = item["reviews"][0][:20]
        attributes = attrs(item["attributes"])
        # line = json.dumps(item, ensure_ascii=False)
        fields = [item["skuid"], review, attributes]
        doc.append("\t".join(fields))
        line = f.readline()
    if item_count % 100000 == 0:
        print("正在读取", item_count)

    f.close()
    # random.shuffle(doc)
    print(time() - t0, "秒读出", item_count, "条")
    t0 = time()
    with open(review1_path, "w", encoding="utf-8") as f:
        f.write("\n".join(doc))
    print(time() - t0, "秒写入只留一条评论，共", len(doc), "条")


def filter(path, sku_counter, min_count=100):
    t0 = time()
    print("review1正在读取", os.path.abspath(path))

    hot = []
    doc = open(path, "r", encoding="utf-8").read().splitlines()
    for line in doc:
        item = line.split("\t")
        if sku_counter[item[0]] < 100:
            continue
        attributes = json.dumps(item["attributes"])
        fields = [item["skuid"], item["reviews"], attributes]
        hot.append(fields)

    with open("data/hot.tsv", "w", encoding="utf-8") as f:
        f.write("\n".join(doc))
    print(time() - t0, "秒写入筛出的", len(doc), "条")


def combine_data(qa_path, context_path):
    return


def main():
    jsonl_path = "../../data/jd/train-anon.jsonl.1000"
    review1_path = "../data/review1.jsonl"
    review1(jsonl_path, review1_path)
    skuqa_path = "../../data/jd/all-anon.skuqa.1000"
    sku_counter = sku_count(skuqa_path)
    # print(skuqa_path)


if __name__ == '__main__':
    main()
