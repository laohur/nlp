# -*- coding: utf-8 -*-
import os
import torch
import torch.utils.data
import argparse
from tqdm import tqdm
from dataset import collate_fn, SeqDataset
from transformer.Translator import Translator
from preprocess import load_file, convert_w2id_seq
import json


def main():
    # test_path="../data/tb/test_src.txt"
    test_path="../data/qa_data/test_src.txt"
    parser = argparse.ArgumentParser(description='main_test.py')
    parser.add_argument('-model', default="log/model.ckpt", help='模型路径')
    parser.add_argument('-src', default=test_path, help='测试集源文件路径')
    parser.add_argument('-data', default="data/reader.data", help='训练数据')
    parser.add_argument('-output_dir', default="output", help="输出路径")
    parser.add_argument('-beam_size', type=int, default=5, help='Beam size')
    parser.add_argument('-batch_size', type=int, default=4, help='Batch size')
    parser.add_argument('-n_best', type=int, default=3, help="""多句输出""")
    # parser.add_argument('-cuda', action='store_true', default=torch.cuda.is_available())
    parser.add_argument('-cuda', action='store_true', default=False)

    args = parser.parse_args()
    if not os.path.exists(args.output_dir):
        os.mkdir(args.output_dir)

    # Prepare DataLoader
    # with open(args.data, "r", encoding="utf-8") as f:
    #     preprocess_data = json.load(f)
    print("加载词汇表",os.path.abspath(args.data))
    preprocess_data = torch.load(args.data)
    preprocess_settings = preprocess_data['settings']
    # test_src_word_insts = load_file(args.src, preprocess_settings["max_word_seq_len"], preprocess_settings["keep_case"])
    test_src_word_insts = load_file(args.src, preprocess_settings.max_word_seq_len, preprocess_settings.keep_case, begin=0, end=100)
    test_src_insts = convert_w2id_seq(test_src_word_insts, preprocess_data['dict']['src'])

    test_loader = torch.utils.data.DataLoader(
        SeqDataset(
            src_word2idx=preprocess_data['dict']['src'],
            tgt_word2idx=preprocess_data['dict']['tgt'],
            src_insts=test_src_insts),
        num_workers=2,
        batch_size=args.batch_size,
        collate_fn=collate_fn)

    translator = Translator(args)
    path = args.output_dir + '/test_out.txt'
    with open(path, 'w') as f:
        for batch in tqdm(test_loader, mininterval=2, desc='  - (Test)', leave=False):
            all_hyp, all_scores = translator.translate_batch(*batch)
            for idx_seqs in all_hyp:
                answers = []
                for idx_seq in idx_seqs:
                    pred_line = ''.join([test_loader.dataset.tgt_idx2word[idx] for idx in idx_seq])
                    answers.append(pred_line)
                f.write("\t".join(answers) + '\n')
    print('[Info] 测试完成，文件写入' + path)


if __name__ == "__main__":
    main()
