# -*- coding: utf-8 -*-
import os
import torch
import torch.utils.data
import argparse
from tqdm import tqdm
from dataset import SeqDataset, paired_collate_fn, tri_collate_fn
from transformer.Translator import Translator
from preprocess import load_file, convert_w2id_seq
import json
from Util import *


def main():
    # test_path="../data/tb/test_src.txt"
    # test_path = "../data/qa_data/test_src.txt"
    data_dir = "data"
    parser = argparse.ArgumentParser(description='main_test.py')
    parser.add_argument('-model', default="log/model.ckpt", help='模型路径')
    parser.add_argument('-data_dir', default=data_dir, help='模型路径')
    parser.add_argument('-src', default=data_dir + "/test_src.txt", help='测试集源文件路径')
    parser.add_argument('-data', default="data/reader.data", help='训练数据')
    parser.add_argument('-output_dir', default="output", help="输出路径")
    parser.add_argument('-beam_size', type=int, default=5, help='Beam size')
    parser.add_argument('-batch_size', type=int, default=64, help='Batch size')
    parser.add_argument('-n_best', type=int, default=3, help="""多句输出""")
    parser.add_argument('-device', action='store_true', default=device)

    args = parser.parse_args()
    if not os.path.exists(args.output_dir):
        os.mkdir(args.output_dir)

    # Prepare DataLoader
    # Prepare DataLoader
    # with open(args.data, "r", encoding="utf-8") as f:
    #     preprocess_data = json.load(f)
    print("加载词汇表", os.path.abspath(args.data))
    reader = torch.load(args.data)
    preprocess_settings = reader['settings']
    # test_src_word_insts = load_file(args.src, preprocess_settings["max_word_seq_len"], preprocess_settings["keep_case"])
    # test_src_word_insts = load_file(args.src, preprocess_settings.max_word_seq_len, preprocess_settings.keep_case,
    #                                 begin=0, end=100)
    # test_src_insts = convert_w2id_seq(test_src_word_insts, preprocess_data['dict']['src'])
    test_src = read_file(path=args.data_dir + "/test_src.txt")
    test_ctx = read_file(path=args.data_dir + "/test_attr.txt")
    test_src, test_ctx, _ = digitalize(src=test_src, tgt=None, ctx=test_ctx, max_sent_len=20,
                                       word2idx=reader['dict']['src'], index2freq=None, topk=0)

    test_loader = torch.utils.data.DataLoader(
        SeqDataset(
            src_word2idx=reader['dict']['src'],
            tgt_word2idx=reader['dict']['tgt'],
            ctx_word2idx=reader['dict']['ctx'],
            src_insts=test_src,
            ctx_insts=test_ctx),
        num_workers=4,
        batch_size=args.batch_size,
        collate_fn=paired_collate_fn)

    bad_words = ['您', '建', '猜', '查', '吗', '哪', '了', '问', '么', '&']
    bad_idx = [0, 1, 2, 3] + [reader['dict']['src'][w] for w in bad_words]
    # 最后一个批次不等长
    bads = torch.ones((1, len(reader['dict']['tgt'])))
    for i in bad_idx:
        bads[0][i] = 100  # log(prob)<0  分别观察 0.01  100

    args.bad_mask = bads
    translator = Translator(args)
    path = args.output_dir + '/test_out.txt'
    with open(path, 'w', encoding="utf-8") as f:
        for batch in tqdm(test_loader, mininterval=2, desc='  - (Test)', leave=False):
            all_hyp, all_scores = translator.translate_batch(*batch)
            for idx_seqs in all_hyp:  # batch
                answers = []
                for idx_seq in idx_seqs:  # n_best
                    pred_line = ' '.join([test_loader.dataset.tgt_idx2word[idx] for idx in idx_seq])
                    answers.append(pred_line)
                f.write("\t".join(answers) + '\n')
    print('[Info] 测试完成，文件写入' + path)


if __name__ == "__main__":
    main()
