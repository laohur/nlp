import torch
import torchtext
from torchtext import data
from torchtext.data import Field
from Util import *
import Constants
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from torch.autograd import Variable as V
from tqdm import tqdm
from torchtext.data import Iterator, BucketIterator

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

dir = "../data/chitchat_data/"
TEXT = Field(sequential=True, tokenize=split_lans, lower=True, batch_first=True,
             init_token=Constants.BOS, eos_token=Constants.EOS, pad_token=Constants.PAD_WORD,
             unk_token=Constants.UNK_WORD)
tv_datafields = [("source", TEXT), ("target", TEXT)]  # 没有header，可以自动从tsv分开
train, valid, test = torchtext.data.TabularDataset.splits(
    path=dir,  # the root directory where the data lies
    train='train.txt', validation="valid.txt", test="test.txt",
    format='tsv',
    skip_header=False,
    fields=tv_datafields
)
# train, valid, test = torchtext.datasets.LanguageModelingDataset.splits 不支持多字段


TEXT.build_vocab(train, valid, test, max_size=20000, min_freq=5)
test_iter = Iterator(test, batch_size=64, device=device, sort=False, sort_within_batch=False, repeat=False)

# First, PyTorch’s current solution for masked BPTT is slightly bizzare, it requires you to pack the
train_iter, valid_iter = data.BucketIterator.splits(
    (train, valid),
    batch_sizes=(32, 256),
    device=device,
    sort_key=lambda x: max(len(x.source),len(len(x.target))),
    sort_within_batch=False,
    # the BucketIterator needs to be told what function it should use to group the data.
    repeat=False)


class RNNModel(nn.Module):
    def __init__(self, ntoken, ninp,
                 nhid, nlayers, bsz,
                 dropout=0.5, tie_weights=True):
        super(RNNModel, self).__init__()
        self.nhid, self.nlayers, self.bsz = nhid, nlayers, bsz
        self.drop = nn.Dropout(dropout)
        self.encoder = nn.Embedding(num_embeddings=ntoken, embedding_dim=ninp, padding_idx=0)
        self.rnn = nn.LSTM(ninp, nhid, nlayers, dropout=dropout, batch_first=True)
        self.decoder = nn.Linear(nhid, ntoken)  # 一个线性解码器，不管seq了
        self.init_weights()
        self.hidden = self.init_hidden(bsz)  # the input is a batched consecutive corpus
        # therefore, we retain the hidden state across batches

    def init_weights(self):
        initrange = 0.1
        self.encoder.weight.data.uniform_(-initrange, initrange)
        self.decoder.bias.data.fill_(0)
        self.decoder.weight.data.uniform_(-initrange, initrange)

    def forward(self, input):
        batch_size, seq_len = input.shape[0], input.shape[1]
        emb = self.drop(self.encoder(input))  # batch_size*length*nemb
        output, self.hidden = self.rnn(emb, self.hidden)  # hidden=(hn,cn) hn=nlayers*batch_size*nhidden
        output = self.drop(output)  # batch_size*length*nhidden
        decoded = self.decoder(output.view(batch_size * seq_len, self.nhid))  # batch_size**length*ntoken
        ntoken = decoded.shape[1]
        return decoded.view(batch_size, seq_len, ntoken)

    def init_hidden(self, bsz):
        weight = next(self.parameters()).data
        return (V(weight.new(self.nlayers, bsz, self.nhid).zero_().to(device)),
                V(weight.new(self.nlayers, bsz, self.nhid).zero_()).to(device))

    def reset_history(self):
        """Wraps hidden states in new Variables, to detach them from their history."""
        self.hidden = tuple(V(v.data) for v in self.hidden)


model = RNNModel(ntoken=len(TEXT.vocab), ninp=256, nhid=200, nlayers=3, bsz=32).to(device)
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=1e-3, betas=(0.7, 0.99))


def train_epoch(epoch):
    """One epoch of a training loop"""
    epoch_loss = 0
    for batch in tqdm(train_iter):
        # reset the hidden state or else the model will try to backpropagate to the
        # beginning of the dataset, requiring lots of time and a lot of memory
        model.reset_history()
        optimizer.zero_grad()

        source, target = batch.source, batch.target  # batch_size*length1,2
        prediction = model(source)  # batch_size*length*
        # pytorch currently only supports cross entropy loss for inputs of 2 or 4 dimensions.
        # we therefore flatten the predictions out across the batch axis so that it becomes
        # shape (batch_size * sequence_length, n_tokens)
        # in accordance to this, we reshape the targets to be
        # shape (batch_size * sequence_length)
        loss = criterion(prediction.view(-1, len(TEXT.vocab)), target.view(-1))
        loss.backward()

        optimizer.step()

        epoch_loss += loss.data[0] * prediction.size(0) * prediction.size(1)

    epoch_loss /= len(train.examples[0].source)

    # monitor the loss
    val_loss = 0
    model.eval()
    for batch in valid_iter:
        model.reset_history()
        source, target = batch.source, batch.target
        prediction = model(source)
        loss = criterion(prediction.view(-1, len(TEXT.vocab)), target.view(-1))
        val_loss += loss.data[0] * source.size(0)
    val_loss /= len(valid.examples[0].text)

    print('Epoch: {}, Training Loss: {:.4f}, Validation Loss: {:.4f}'.format(epoch, epoch_loss, val_loss))


n_epochs = 2
for epoch in range(1, n_epochs + 1):
    train_epoch(epoch)

b = next(iter(valid_iter))
print(b)


def word_ids_to_sentence(id_tensor, vocab, join=None):
    """Converts a sequence of word ids to a sentence"""
    if isinstance(id_tensor, torch.LongTensor):
        ids = id_tensor.transpose(0, 1).contiguous().view(-1)
    elif isinstance(id_tensor, np.ndarray):
        ids = id_tensor.transpose().reshape(-1)

    batch = [vocab.itos[ind] for ind in ids]  # denumericalize
    if join is None:
        return batch
    else:
        return join.join(batch)


word_ids_to_sentence(b.text.cpu().data, TEXT.vocab, join=' ')[:210]
arrs = model(b.text).cpu().data.numpy()
word_ids_to_sentence(np.argmax(arrs, axis=2), TEXT.vocab, join=' ')[:210]

# Hmm.. doesn't seem to be making much sense yet. Let's train for another 2 epochs and see how the results change
for epoch in range(n_epochs + 1, n_epochs * 2 + 1):
    train_epoch(epoch)

arrs = model(b.text).cpu().data.numpy()
word_ids_to_sentence(np.argmax(arrs, axis=2), TEXT.vocab, join=' ')[:210]
