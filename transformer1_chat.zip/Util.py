'''
文件读写，字频统计，词典转换

'''


import os
import re
from time import time
import random
import Constants
import sys
import torch
import json

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def unicode_type(unicode):  # 判断字符类型
    # https://gist.github.com/shingchi/64c04e0dd2cbbfbc1350
    if ord(unicode) <= 0x007f:  # ascii
        if ord(unicode) >= 0x0041 and ord(unicode) <= 0x005a:
            return "latin"
        if ord(unicode) >= 0x0061 and ord(unicode) <= 0x007a:
            return "latin"
        return "ascii_symble"
    if ord(unicode) >= 0x4E00 and ord(unicode) <= 0x9fff:
        return "han"  # 标准CJK文字
    if ord(unicode) >= 0xFF00 and ord(unicode) <= 0xFFEF:
        return "han_symble"  # 全角ASCII、全角中英文标点、半宽片假名、半宽平假名、半宽韩文字母：FF00-FFEF
    if ord(unicode) >= 0x3000 and ord(unicode) <= 0x303F:
        return "han_symble"  # CJK标点符号：3000-303F
    return "other"

def split_lans(line):
    last_latin=None
    grams=[]
    for gram in line:
        if unicode_type(gram)=="latin":
            if last_latin == None or last_latin== False :
                grams.append(gram)
            else:
                grams[-1]+=gram
            last_latin=True
        else:
            grams.append(gram)
            last_latin=False
    return grams


def count_word(counter, word, n=1): #统计词频  累加n
    if word not in counter:
        counter[word] = n
    else:
        counter[word] += n

def sort_counter(counter, reverse=True): #词频降序
    items = sorted(counter.items(), key=lambda kv: kv[1], reverse=reverse)
    counter = dict(items)
    return counter

def counter2frequency(counter):
    sum=0
    for word,num in counter.items():
        sum+=num
    frequency={}
    for word, num in counter.items():
        frequency[word]=num/sum
    return frequency

def counter2dict(counter,word2index=Constants.Default_Dict, min_word_count=2):  # 生成字典
    ignored_word_count = 0
    for word, count in counter.items():
        if word not in word2index:
            if count >= min_word_count:
                word2index[word] = len(word2index)
            else:
                ignored_word_count += 1
    print('[Info] 频繁字典大小 = {},'.format(len(word2index)), '最低频数 = {}'.format(min_word_count))
    print("[Info] 忽略罕词数 = {}".format(ignored_word_count))
    return word2index

def get_index2word(word2index):
    index2word=[]
    for word, count in word2index.items():
        index2word.append(word)
    return index2word

def sentence2indices(word2index,line,unk=Constants.UNK):
    result= [word2index.get(word,unk) for word in line]
    return result

def indices2sentence(index2word, indices):
    sentence = "".join(index2word[index] for index in indices)
    return sentence

def digitize( doc, word2index):
    batch=[]
    for line in doc:
        batch.append(sentence2indices(word2index,line))
    return batch

def split_train(x,rate=0.90,shuffle=True):
    if  shuffle:
        random.shuffle(x)
    index=int(len(x)*rate)
    train=x[:index]
    test=x[index:]
    index=int(len(test)*0.9)
    valid=test[:index]
    test=test[index:]
    return train, valid, test

def write_splits(x,dir="data",shuffle=True):
    if  shuffle:
        random.shuffle(x)
    left=int(len(x)*0.9)
    right=left+int(0.9*(len(x)-left))

    with open(dir+"/train.txt","w",encoding="utf-8") as f:
        f.write("\n".join(x[:left]))
    with open(dir+"/valid.txt","w",encoding="utf-8") as f:
        f.write("\n".join(x[left:right]))
    with open(dir+"/test.txt","w",encoding="utf-8") as f:
        f.write("\n".join(x[right:]))
    print("训练集、验证集、测试集已写入",dir,"目录下")

def read_start_of_line( fp):
    n = int(1e6)
    tmp = result = fp.readline(n)
    while tmp and tmp[-1] != '\n':
        tmp = fp.readline(n)
    return result

def read_doc(path,case=False):
    print("统计文件", os.path.abspath(path))
    with open(path, "r", encoding='utf-8') as f:
        doc=f.read().splitlines()
    print(os.path.abspath(path), "总行数",len(doc), "体积", sys.getsizeof(doc))
    for i in range(len(doc)):
        if i%100000==0:
            print("正在处理第", i, "行， 长度", len(doc[i]))
        doc[i]=" ".join(get_grams(doc[i]))
        if not case:
            doc[i]=doc[i].lower()
    print("分词后体积", sys.getsizeof(doc))
    return doc

def count_doc(doc,counter={}):
    # for index, line in enumerate(iter(lambda: read_start_of_line(reade_file), '')):
    for line in doc:
        words=line.split(" ")
        for word in words:
            if word:
                count_word(counter,word)
    return sort_counter(counter)

def write_counter(path,counter,frequency={}):
    f= open(path, 'w', encoding="utf8")
    for word, num in counter.items():
        line=word+"\t"+str(num)
        if frequency is not None:
            line+="\t"+str(frequency[word]*10000)
        f.write(line+"\n")
    print("写入"+os.path.abspath(path))
    f.close()

def merge_counter(counter1,counter2):
    if len(counter1)>0:
        for word, num in counter1.items():
            count_word(counter2,word, num)
    return sort_counter(counter2)

def load_counter(path,counter0={}):
    counter={}
    print("读取"+os.path.abspath(path))
    with open(path, 'r', encoding="utf8") as f:
        data=f.read().splitlines()
    for line in data:
        words= line.split("\t")
        if len(words)!=3:
            continue
        counter[words[0]]=int(float(words[1]))
    return merge_counter(counter0,counter)


def main():
    paths=["D:/algorithm/对话/data/ChitChat/chitchat_data.txt",
           "D:/algorithm/对话/data/ChitChat/chitchat_data.1000.txt"
        ]
    # t0=time()
    # doc = read_doc(paths[0])
    # print("分词",time() - t0)
    #
    # t0 = time()
    # counter=count_doc(doc)
    # frequency=counter2frequency(counter)
    # write_counter("data/chit_chat_counter.tsv",counter,frequency)
    # print("词频",time() - t0)
    #
    # t0 = time()
    # write_splits(doc)
    # print("划分训练集",time()-t0)
    # t0=time()

    counter_path="data/chit_chat_counter.tsv"
    counter=load_counter(counter_path)
    dict=counter2dict(counter)
    print(dict)
    doc=open(paths[0],"r",encoding="utf-8").read().strip().splitlines()
    doc=digitize(doc,dict)

def json_dict():
    paths=["D:/algorithm/对话/data/ChitChat/chitchat_data.txt",
           "D:/algorithm/对话/data/ChitChat/chitchat_data.1000.txt"        ]

    doc=read_doc((paths[0]))
    counter=count_doc(doc)
    with open("data/counter.json","r",encoding="utf-8") as f:
        json.dump(counter,f,ensure_ascii=False)



if __name__ == "__main__":
    t0 = time()
    json_dict()
    print("耗时",time()-t0)
