# -*- coding: utf-8 -*-
import os
import argparse
import torch
import torch.utils.data
from transformer.Models import Transformer
from transformer.Optim import ScheduledOptim
# from trainer import train
from trainer import train
from reader import *
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def main(required):
    parser = argparse.ArgumentParser(description='main_train.py')
    parser.add_argument('-dir', default=required["dir"])
    parser.add_argument('-reader', default=required["dir"]+"/reader.pkl")
    parser.add_argument('-epoch', type=int, default=20)
    parser.add_argument('-batch_size', type=int, default=64)

    parser.add_argument('-d_word_vec', type=int, default=512)
    parser.add_argument('-d_model', type=int, default=512)
    parser.add_argument('-d_inner_hid', type=int, default=2048)
    parser.add_argument('-d_k', type=int, default=64)
    parser.add_argument('-d_v', type=int, default=64)
    parser.add_argument('-n_head', type=int, default=8)
    parser.add_argument('-n_layers', type=int, default=6)
    parser.add_argument('-n_warmup_steps', type=int, default=4000)
    parser.add_argument('-dropout', type=float, default=0.1)
    parser.add_argument('-embs_share_weight', action='store_true')
    parser.add_argument('-proj_share_weight', action='store_true', default=True)
    parser.add_argument('-label_smoothing', action='store_true', default=True)

    # parser.add_argument('-log', required=True)
    # parser.add_argument('-log', default=required["dir"]+"/"+required["log"])
    parser.add_argument('-log', default=required["log"])
    parser.add_argument('-save_model', default="model")
    parser.add_argument('-save_mode', type=str, choices=['all', 'best'], default='best')
    # parser.add_argument('-no_cuda', action='store_true')
    parser.add_argument('-cuda', action='store_true', default=torch.cuda.is_available())

    args = parser.parse_args()
    # args.cuda = not args.no_cuda
    if not os.path.exists(args.log):
        os.mkdir(args.log)

    print("加载数据集")
    reader = torch.load(args.reader)
    args.max_token_seq_len = reader.max_token_seq_len
    reader.gen_dict()

    train_x,train_y=reader.load_file(args.dir+"/"+"train.txt")
    valid_x,valid_y=reader.load_file(args.dir+"/"+"valid.txt")

    validation_data=prepare_dataloaders(valid_x,valid_y,reader,args)
    training_data=prepare_dataloaders(train_x,train_y,reader,args)


    args.src_vocab_size = training_data.dataset.src_vocab_size
    args.tgt_vocab_size = training_data.dataset.tgt_vocab_size

    print("准备模型")
    if args.embs_share_weight:
        assert training_data.dataset.src_word2idx == training_data.dataset.tgt_word2idx, \
            'The src/tgt word2idx table 不同 但共用word embedding.'

    print(args)

    transformer = Transformer(
        args.src_vocab_size,
        args.tgt_vocab_size,
        args.max_token_seq_len,
        tgt_emb_prj_weight_sharing=args.proj_share_weight,
        emb_src_tgt_weight_sharing=args.embs_share_weight,
        d_k=args.d_k,
        d_v=args.d_v,
        d_model=args.d_model,
        d_word_vec=args.d_word_vec,
        d_inner=args.d_inner_hid,
        n_layers=args.n_layers,
        n_head=args.n_head,
        dropout=args.dropout).to(device)

    args_optimizer = ScheduledOptim(
        torch.optim.Adam(
            filter(lambda x: x.requires_grad, transformer.parameters()),
            betas=(0.9, 0.98), eps=1e-03),
        args.d_model, args.n_warmup_steps)

    train(transformer, training_data, validation_data, args_optimizer, device, args)


if __name__ == '__main__':
    required={
         "dir": "data",
         "log": "log",
         "save_model": "train",
         "save_mode":"all",
         "proj_share_weight": "True",
         "label_smoothing": "True",
         "cuda": torch.cuda.is_available()
     }

    main(required)
