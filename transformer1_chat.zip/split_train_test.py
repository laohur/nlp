from Util import *

dir="../data/chitchat_data/"
source=dir+"/chitchat_data.1000.txt"
train_text_dir=dir

doc=open(source,"r",encoding="utf-8").read().splitlines()
write_splits(doc,train_text_dir)
