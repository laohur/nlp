# from Dict import *
import transformer.Constants as Constants
from dataset import SeqDataset, paired_collate_fn
import os
import torch
import random

class Reader():
    def __init__(self,config=None):
        self.min_word_count=2
        self.max_sent_len=20
        self.keep_case=False
        self.counter={}
        self.word2index = {
            Constants.BOS_WORD: Constants.BOS,
            Constants.EOS_WORD: Constants.EOS,
            Constants.PAD_WORD: Constants.PAD,
            Constants.UNK_WORD: Constants.UNK}
        self.index2word=[Constants.BOS_WORD, Constants.EOS_WORD, Constants.PAD_WORD, Constants.UNK_WORD]
        self.trimmed_sent_count=0
        self.max_token_seq_len=self.max_sent_len+2 #<s> </s>

    def count_word(self, word):
        if word not in self.counter:
            self.counter[word] = 1
        else:
            self.counter[word] += 1

    def gen_dict(self):
        ignored_word_count = 0
        for word, count in self.counter.items():
            if word not in self.word2index:
                if count >= self.min_word_count:
                    self.word2index[word] = len(self.word2index)
                    self.index2word.append(word)
                else:
                    ignored_word_count += 1
        print('[Info] 频繁字典大小 = {},'.format(len(self.word2index)), '最低频数 = {}'.format(self.min_word_count))
        print("[Info] 忽略罕词数 = {}".format(ignored_word_count))
        return self.word2index, self.index2word


    def sentence2indices(self,line):
        result= [self.word2index.get(word,Constants.UNK) for word in line]
        # if len(result)>=self.max_len:
        #     result= result[:self.max_len]
        # else:
        #     b=[Constants.PAD]*(self.max_len-len(result))
        #     result+=b
        # assert len(result)==self.max_len

        return result

    def indices2sentence(self, indices):
        sentence = "".join(self.index2word[index] for index in indices)
        return sentence

    def digitize(self, origin):
        batch=[]
        for line in origin:
            # print(line)
            batch.append(self.sentence2indices(line))
        print(batch[0])
        # print( Variable(torch.LongTensor(batch)).shape)
        # return Variable(torch.LongTensor(batch))
        return batch

    def lan_type(self,unicode):
        # https://gist.github.com/shingchi/64c04e0dd2cbbfbc1350
        if ord(unicode) <=0x007f:  #ascii
            if ord(unicode) >= 0x0041 and ord(unicode) <= 0x005a:
                return "latin"
            if ord(unicode) >= 0x0061 and ord(unicode) <= 0x007a:
                return "latin"
            return "symble"
        if ord(unicode) >= 0x4E00 and ord(unicode) <= 0x9fff:
            return "han" #标准CJK文字
        if ord(unicode) >= 0xFF00 and ord(unicode) <= 0xFFEF:
            return "han"  #全角ASCII、全角中英文标点、半宽片假名、半宽平假名、半宽韩文字母：FF00-FFEF
        if ord(unicode) >= 0x3000 and ord(unicode) <= 0x303F:
            return "han" #CJK标点符号：3000-303F
        return "other"

    def break_gram(self,line):
        line2=""
        for gram in line:
            if self.lan_type(gram)!="latin":
                gram=" "+gram+" "
            line2+=gram
        return line2.replace("  "," ")


    def pure(self,line):
        words = line.split()
        if len(words) > self.max_sent_len:
            self.trimmed_sent_count += 1
        # 左截断，左右各一半更好
        word_inst = words[:self.max_sent_len]
        line = [[Constants.BOS_WORD] + word_inst + [Constants.EOS_WORD]] if word_inst else [None]
        return line

    def read_file(self,path,keep_case=False):
        doc=[]
        f=open(path,"r",encoding='utf-8')
        n=0
        for sent in f:
            n+=1
            if n%100000==0:
                print(os.path.abspath(path)+"读到",n)
            sent=sent.replace("\n",'').replace("\r",'')
            if not keep_case:
                sent = sent.lower()
            if len(sent.split("\t"))!=2:
                continue
            sent=self.break_gram(sent)
            for word in sent.split(" "):
                if word is not None :
                    self.count_word(word)
            doc.append(sent)
        return doc

    def load_file(self,path):
        trimmed_sent_count = 0
        questions,answers=[],[]
        f=open(path,"r",encoding='utf-8')
        n=0
        for sent in f:
            n+=1
            if n%100000==0:
                print(os.path.abspath(path)+"读到",n)
            lines=sent.split("\t")
            assert len(lines)==2
            question,answer=lines[0],lines[1]
            question,answer=self.pure(question),self.pure(answer)
            questions+=question
            answers+=answer

        print('[Info] ""文件{}中获取{}句子'.format(path, len(answers)))
        if trimmed_sent_count > 0:
            print('[Warning] {}个句子被截断至最大长度{}.'.format(trimmed_sent_count, self.max_sent_len))

        return questions,answers

def writeto(data,path):
    f= open(path, 'w', encoding="utf8")
    for line in data:
        f.write(line+"\n")
    print("被写入"+os.path.abspath(path))
    f.close()

def split_train(x,rate=0.90,shuffle=True):
    if  shuffle:
        random.shuffle(x)
    index=int(len(x)*rate)
    train=x[:index]
    test=x[index:]
    index=int(len(test)*0.9)
    valid=test[:index]
    test=test[index:]
    return train, valid, test

'''
    train, valid, test = [], [], []
    for sample in x:
        p = random.random()
        if p < 0.9:
            train.append(sample)
        elif p < 0.99:
            valid.append(sample)
        else:
            test.append(sample)

def get_dataloader(x,y,batch_size=10):

    train=Data.TensorDataset(train_x, train_y)
    train_loader=Data.DataLoader(dataset=train,batch_size=batch_size,num_workers=2,shuffle=True)
    test = Data.TensorDataset(test_x, test_y)
    test_loader = Data.DataLoader(dataset=test, batch_size=batch_size,num_workers=2, shuffle=True)
    valid_loader=Data.DataLoader(dataset= Data.TensorDataset(valid_x, valid_y),batch_size=batch_size,num_workers=2,shuffle=True)

    return train_loader,valid_loader,test_loader
'''

def prepare_dataloaders(x,y,reader, args):
    x=reader.digitize(x)
    y=reader.digitize(y)

    train_loader = torch.utils.data.DataLoader(
        SeqDataset(
            src_word2idx=reader.word2index,
            tgt_word2idx=reader.word2index,
            src_insts=x,
            tgt_insts=y),
        num_workers=4,
        batch_size=args.batch_size,
        collate_fn=paired_collate_fn,
        shuffle=True)

    return train_loader
