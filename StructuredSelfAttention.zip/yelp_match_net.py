import torch
import torch.nn as nn
import torch.nn.functional as F

torch.manual_seed(42)
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


class ConvLayerWithBatchNorm(nn.Module):

    def __init__(self, in_channels, out_channels=64, kernel_size=3, padding=1, dropout_probality=0.2):
        super().__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, padding=padding)
        self.ReLU = nn.ReLU()
        self.batch_norm_layer = nn.BatchNorm2d(out_channels)
        self.maxpool = nn.MaxPool2d(2, 2)
        self.dropout = nn.Dropout(dropout_probality)  # Dropout to add regularization and improve model generalization

    def forward(self, X):
        x = self.conv(X)
        x = self.ReLU(x)
        x = self.batch_norm_layer(x)
        x = self.maxpool(x)
        x = self.dropout(x)
        return x


class ConvEmbedding(nn.Module):

    def __init__(self, in_channels=1, embedding_size=256, dropout_probality=0.2):
        super().__init__()
        self.conv1 = ConvLayerWithBatchNorm(in_channels, 64, dropout_probality=dropout_probality)
        self.conv2 = ConvLayerWithBatchNorm(64, 64, dropout_probality=dropout_probality)
        self.conv3 = ConvLayerWithBatchNorm(64, 64, dropout_probality=dropout_probality)
        self.conv4 = ConvLayerWithBatchNorm(64, 64, dropout_probality=dropout_probality)
        self.dense = nn.Linear(64, embedding_size)
        self.dropout = nn.Dropout(dropout_probality)  # Dropout to add regularization and improve model generalization
        self.embedding_size = embedding_size

    def forward(self, X):
        # Input shape is (batch_size, 1, 28, 28)
        x = self.conv1(X)  # x's Shape (batch_size, 64, 14, 14)
        x = self.conv2(x)  # x's Shape (batch_size, 64, 7, 7)
        x = self.conv3(x)  # x's Shape (batch_size, 64, 3, 3)
        x = self.conv4(x)  # x's Shape (batch_size, 64, 1, 1)
        x = x.view(x.size()[0], -1)  # x's Shape (batch_size, 64)
        x = self.dense(x)  # x's Shape (batch_size, embedding_size)
        x = self.dropout(x)  # x's Shape (batch_size, embedding_size) with a few activations flipped to 0
        return x


class FullyConditionalEmbeddingTargetImage(nn.Module):

    def __init__(self, embedding_size, processing_steps=10):
        super().__init__()
        self.lstm_cell = torch.nn.LSTMCell(embedding_size, embedding_size)
        self.processing_steps = processing_steps
        self.embedding_size = embedding_size
        self.attn_softmax = nn.Softmax(dim=1)

    def forward(self, target_image_encoded, support_images_encoded):
        batch_size, num_images, _ = support_images_encoded.shape

        #     hidden_state_prev = torch.zeros(batch_size, self.embedding_size).to(device)
        cell_state_prev = torch.zeros(batch_size, self.embedding_size).to(device)
        hidden_state_prev = torch.sum(support_images_encoded, dim=1) / num_images
        for i in range(self.processing_steps):
            hidden_out, cell_out = self.lstm_cell(target_image_encoded, (hidden_state_prev, cell_state_prev))
            hidden_out = hidden_out + target_image_encoded
            attn = self.attn_softmax(torch.bmm(support_images_encoded, hidden_out.unsqueeze(2)))
            attended_values = torch.sum(attn * support_images_encoded, dim=1)
            hidden_state_prev = hidden_out + attended_values
            cell_state_prev = cell_out

        return hidden_out


class FullyConditionalEmbeddingSupportImages(nn.Module):

    def __init__(self, embedding_size):
        super().__init__()
        self.embedding_size = embedding_size
        self.bidirectionalLSTM = nn.LSTM(input_size=embedding_size, hidden_size=embedding_size, bidirectional=True,
                                         batch_first=True)

    def initialize_hidden(self, batch_size):
        # Initialize the states needed for our bi-directional LSTM
        hidden_state = torch.zeros(2, batch_size, self.embedding_size).to(device)
        cell_state = torch.zeros(2, batch_size, self.embedding_size).to(device)
        return (hidden_state, cell_state)

    def forward(self, support_embeddings):
        batch_size, num_images, _ = support_embeddings.shape
        # Initialize states
        lstm_states = self.initialize_hidden(batch_size)
        # Get the LSTM Outputs
        support_embeddings_contextual, internal_states = self.bidirectionalLSTM(support_embeddings, lstm_states)
        # Get the forward and backward outputs
        support_embeddings_contextual = support_embeddings_contextual.view(batch_size, num_images, 2,
                                                                           self.embedding_size)
        # Add the forward and backward outputs
        support_embeddings_contextual = torch.sum(support_embeddings_contextual, dim=2)
        # Add the skip connection to our output
        support_embeddings_contextual = support_embeddings_contextual + support_embeddings
        return support_embeddings_contextual


class CosineDistance(nn.Module):

    def __init__(self):
        super().__init__()

    def forward(self, target_image, support_images):
        support_images_normed = F.normalize(support_images, p=2, dim=2)
        # the 'p=2' param represents squared norm
        target_image_normed = F.normalize(target_image, p=2, dim=1)
        target_image_normed = target_image_normed.unsqueeze(dim=1).permute(0, 2, 1)
        # This will cause the dimensions to be [5, 64, 1]
        similarities = torch.bmm(support_images_normed, target_image.unsqueeze(1).permute(0, 2, 1))
        # torch.bmm = batch matrix multiply
        # [5, 20, 64] @ [5, 64, 1]
        # the output shape is [5, 20, 1]
        similarities = similarities.squeeze(dim=2)
        # remove last dimension
        return similarities


# Taken from @activatedgeeks's answer from https://stackoverflow.com/questions/44461772/creating-one-hot-vector-from-indices-given-as-a-tensor
class ConvertOneHot(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, labels, num_classes):
        batch_size, num_images, _ = labels.size()
        one_hot_labels = torch.Tensor(batch_size, num_images, num_classes).to(labels.device).float().zero_()
        return one_hot_labels.scatter(2, labels, 1)


class MatchingNet(nn.Module):

    def __init__(self, image_shape, embedding_size=256, dropout_probality=0.2, use_fce=True):
        super().__init__()
        self.attn = nn.Softmax(dim=1)
        self.embedding = ConvEmbedding(embedding_size=embedding_size, dropout_probality=dropout_probality)
        self.distance = CosineDistance()
        self.use_fce = use_fce
        self.onehotconverter = ConvertOneHot()
        if self.use_fce:
            self.full_conditional_embedding_support = FullyConditionalEmbeddingSupportImages(
                embedding_size=embedding_size)
            self.full_conditional_embedding_target = FullyConditionalEmbeddingTargetImage(embedding_size=embedding_size)
        self.image_shape = image_shape

    def forward(self, support_images, support_labels, target_image):

        batch_size, num_images, _ = support_labels.size()

        # Get the image encodings from convolutional embedding
        target_image_encoded = self.embedding(target_image)
        support_images_encoded = self.embedding(support_images.view(-1, *self.image_shape)).view(-1, num_images,
                                                                                                 self.embedding.embedding_size)

        if self.use_fce:
            # Get the support images embedding with context
            support_images_encoded = self.full_conditional_embedding_support(support_images_encoded)

            # Get the target image embedding with context
            target_image_encoded = self.full_conditional_embedding_target(target_image_encoded, support_images_encoded)

        # Get the cosine distances between target image and the support images
        distances = self.distance(target_image_encoded, support_images_encoded)

        # Get the attention value based on the distances
        attention = self.attn(distances)

        # Convert the labels into one hot vectors
        support_set_one_hot_labels = self.onehotconverter(support_labels, num_images)

        # Get the prediction logits by attention * one-hot-labels (automatically summed due to the unsqueeze operation)
        prediction_logits = torch.bmm(attention.unsqueeze(1), support_set_one_hot_labels).squeeze()

        # Get the final labels for predictions
        _, prediction_labels = torch.max(prediction_logits, 1)
        return prediction_logits, prediction_labels

def test():
    img_shape = (1, 28, 28)
    matching_net_trial = MatchingNet(img_shape, dropout_probality=0.1, use_fce=False)
    print("Model Summary")
    print(matching_net_trial)
    epochs = 10

    support_images = torch.rand(32, 20, *img_shape)
    target_image = torch.rand(32, *img_shape)
    support_labels = torch.LongTensor(32, 20, 1) % 20
    target_labels = torch.LongTensor(32) % 20

    matching_net_trial.to(device)
    support_images = support_images.to(device)
    support_labels = support_labels.to(device)
    target_image = target_image.to(device)
    target_labels = target_labels.to(device)
    optimizer = torch.optim.Adam(matching_net_trial.parameters(), lr=0.001)
    for epoch in range(epochs):
        logits, predictions = matching_net_trial(support_images, support_labels, target_image)
        loss = F.cross_entropy(logits, target_labels)
        print(loss.item())
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
